import random
import time
import json

Story = False
# Character creation
class Character:
    def __init__(self, name, character_class):
        self.name = name
        self.character_class = character_class
        self.hp = 100
        self.max_hp = 100
        self.gold = 50  # Starting gold
        self.inventory = []
        self.attack_power = 10 if character_class == "Fighter" or "Voidspawn Ascendant" else 7
        self.magic_power = 10 if character_class == "Wizard" or "Voidspawn Ascendant" else 5
        self.dexterity = 10 if character_class == "Rogue" or "Voidspawn Ascendant" else 5
        self.heal_count = 3  # You can heal 3 times
        self.level = 1
        self.xp = 0
        self.active_quests = []
        self.completed_quests = []

    # Get abilities for a character class and level
    def get_character_abilities(self):
        if self.character_class == 'Fighter':
            return FighterAbilities(self.level).abilities
        elif self.character_class == 'Wizard':
            return WizardAbilities(self.level).abilities
        elif self.character_class == 'Rogue':
            return RogueAbilities(self.level).abilities
        else:
            return None

    def attack(self):
        return random.randint(5, self.attack_power)

    def cast_spell(self):
        return random.randint(5, self.magic_power)

    def dodge(self):
        return random.random() < (self.dexterity / 20)

    def heal(self):
        if self.heal_count > 0:
            heal_amount = random.randint(15, 30)
            self.hp = min(self.hp + heal_amount, self.max_hp)
            self.heal_count -= 1
            print(f"You heal for {heal_amount} HP. You have {self.hp} HP now.")
        else:
            print("You're out of healing potions!")

    def use_item(self, item):
        if item.effect == "heal":
            heal_amount = random.randint(20, 40)
            self.hp += heal_amount
            self.inventory.remove(item)
            print(f"You used a {item.name} and healed for {heal_amount} HP. Your HP is now {self.hp}.")
        elif item.effect == "attack_boost":
            boost_amount = random.randint(5, 10)
            self.attack_power += boost_amount
            self.inventory.remove(item)
            print(
                f"You used a {item.name} and gained {boost_amount} attack power! Your attack power is now "
                f"{self.attack_power}.")
        else:
            print("This item has no effect.")

    def buy_item(self, item):
        if self.gold >= item.cost:
            self.gold -= item.cost
            self.inventory.append(item)
            print(f"You bought {item.name} for {item.cost} gold.")
        else:
            print("You don't have enough gold to buy this item!")

    def gain_xp(self, amount):
        self.xp += amount
        print(f"You gained {amount} XP! Total XP: {self.xp}")
        self.check_level_up()

    def check_level_up(self):
        level_up_xp = [0, 100, 500, 1000, 1700, 2500, 3500, 4700, 6700, 9000]  # XP thresholds for levels 1 to 10
        print(f"Current Level: {self.level}, Current XP: {self.xp}")  # Debug statement

        # Check if the character can level up
        while self.level < len(level_up_xp) - 1 and self.xp >= level_up_xp[self.level]:  # Adjust for 0-based index
            self.level += 1
            print(f"Congratulations! You reached Level {self.level}!")
            self.max_hp += 75 # Increase the Maximum Hp
            self.hp = self.max_hp  # Make hp equal to Max hp after level up
            print(f"Your Max HP increased! New HP: {self.max_hp}")

        print(f"New Level: {self.level}, XP Required for Next Level: {level_up_xp[self.level]}")  # Debug statement

    def accept_quest(self, quest):
        self.active_quests.append(quest)
        print(f"You have accepted the quest: {quest.name}")

    def check_quest_progress(self, objective):
        for quest in self.active_quests:
            if quest.objective == objective and not quest.is_completed:
                quest.complete_quest(self)
                self.completed_quests.append(quest)
                self.active_quests.remove(quest)

        # Method to display the player's stats

    def show_stats(self):
        print(f"Name: {self.name}")
        print(f"Class: {self.character_class}")
        print(f"Level: {self.level}")
        print(f"XP: {self.xp}")
        print(f"HP: {self.hp}")
        print(f"Attack: {self.attack_power}")
        print(f"Magic: {self.magic_power}")
        print(f"Dexterity: {self.dexterity}")
        print(f"Free Heals: {self.heal_count}")
        print(f"Gold: {self.gold}")
        # Format and display active quests
        if self.active_quests:
            print("Active Quests: " + ", ".join(str(quest) for quest in self.active_quests))
        else:
            print("Active Quests: (none)")
        # Format and Display inventory
        if self.inventory:
            print("Inventory: " + ", ".join(str(item) for item in self.inventory))
        else:
            print("Inventory: (empty)")


# Item class
class Item:
    def __init__(self, name, effect, cost):
        self.name = name
        self.effect = effect
        self.cost = cost

    def __str__(self):
        return f"{self.name}"


# NPC Class Definition
class NPC:
    def __init__(self, name, role, dialogue, trade_items=None, quest=None):
        self.name = name
        self.role = role  # NPC's role, e.g., "Merchant", "Villager", "Guard"
        self.dialogue = dialogue  # Dictionary of dialogue options and responses
        self.trade_items = trade_items if trade_items else []  # List of items to trade
        self.quest = quest  # Optional quest that the NPC offers

    def interact(self, player):
        print(f"\nYou meet {self.name}, a {self.role}.")
        while True:
            print("\nWhat would you like to do?")
            print("1. Talk")
            print("2. Trade" if self.trade_items else "2. (No trade available)")
            print("3. Ask about a quest" if self.quest else "3. (No quest available)")
            print("4. Leave")

            choice = input("Choose an option: ").lower()

            if choice == "1":
                self.talk()
            elif choice == "2" and self.trade_items:
                self.trade(player)
            elif choice == "3" and self.quest:
                self.give_quest(player)
            elif choice == "4":
                print(f"\nYou leave {self.name}.")
                break
            else:
                print("Invalid choice. Please choose again.")

    def talk(self):
        print("\nYou strike up a conversation.")
        for question, response in self.dialogue.items():
            print(f"\nYou: {question}")
            print(f"{self.name}: {response}")

    def trade(self, player):
        print("\nYou look at the items available for trade:")
        for index, item in enumerate(self.trade_items, 1):
            print(f"{index}. {item['name']} (Price: {item['price']} gold)")

        choice = input("Enter the number of the item you want to buy (or type 'back' to return): ").lower()
        if choice == "back":
            return
        try:
            choice = int(choice)
            if 1 <= choice <= len(self.trade_items):
                selected_item = self.trade_items[choice - 1]
                if player.gold >= selected_item["price"]:
                    player.gold -= selected_item["price"]
                    player.inventory.append(selected_item["name"])
                    print(f"\nYou purchased {selected_item['name']} for {selected_item['price']} gold.")
                else:
                    print("\nYou don't have enough gold.")
            else:
                print("\nInvalid selection.")
        except ValueError:
            print("\nInvalid input.")

    def give_quest(self, player):
        print(f"\n{self.name} gives you a quest: {self.quest['description']}")
        player.active_quests.append(self.quest)
        print("The quest has been added to your journal!")


# Display class stats and descriptions
def show_class_stats1(character_class):
    descriptions = {
        "Fighter": """
        Class: Fighter
        Attack Power: 10
        Magic Power: 5
        Special Trait: High Attack Power and Strong Defense.
        Description: Fighters are versatile warriors, excelling in physical combat.
        They can deal significant damage and withstand heavy hits.
        Level 1: Shield Bash: Stuns the enemy for one turn while dealing damage.
        Level 2: Cleave: Deals damage to two enemies simultaneously.
        Level 3: Battle Cry: Boosts allies' attack power for one turn.
        Level 4: Defensive Stance: Reduces incoming damage for one turn.
        Level 5: Whirlwind Attack: Deals damage to all enemies in range.
        Level 6: 
        Level 7: 
        Level 8: 
        Level 9: 
        Level 10: 
        """,
        "Wizard": """
        Class: Wizard
        Attack Power: 5
        Magic Power: 10
        Special Trait: High Magic Power, capable of casting powerful spells.
        Description: Wizards are masters of the arcane, specializing in casting spells.
        They may be physically weak but can deal great damage with magic.
        Level 1: Magic Missile: Automatically hits the target, dealing damage.
        Level 2: Mage Armor: Increases the wizard's defense for one turn.
        Level 3: Fireball: Deals area damage to multiple enemies.
        Level 4: Invisibility: Makes the wizard invisible for one turn.
        Level 5: Lightning Bolt: Deals heavy damage to a single target.
        Level 6: 
        Level 7: 
        Level 8: 
        Level 9: 
        Level 10: 
        """,
        "Rogue": """
        Class: Rogue
        Attack Power: 7
        Magic Power: 5
        Special Trait: High Dexterity, able to dodge attacks.
        Description: Rogues are quick and agile, relying on speed and precision.
        They are adept at dodging enemy attacks and dealing moderate damage.
        Level 1: Sneak Attack: Deals extra damage when attacking stealthily or with an ally nearby.
        Level 2: Cunning Action: Allows the rogue to use a bonus action for movement or hiding.
        Level 3: Evasion: Avoids damage from area effects with a successful Dexterity save.
        Level 4: Uncanny Dodge: Halves damage from attacks that the rogue can see.
        Level 5: Assassinate: Deals critical damage when attacking surprised enemies.
        Level 6: 
        Level 7: 
        Level 8: 
        Level 9: 
        Level 10: 
        """
    }

    character_class = character_class.capitalize()
    print(descriptions.get(character_class, "Invalid class. No stats available."))


# Class Abilities
class FighterAbilities:
    def __init__(self, level):
        self.level = level
        self.abilities = self.get_abilities()

    def get_abilities(self):
        abilities = []
        if self.level >= 1:
            abilities.append({
                'name': "Shield Bash",
                'description': "A powerful attack that stuns the enemy, reducing their next turn's action.",
                'damage': 10,
                'effect': "stun",
                'stun_duration': 1
            })
        if self.level >= 2:
            abilities.append({
                'name': "Cleave",
                'description': "A sweeping attack that deals damage to two enemies at once.",
                'damage': 15,
                'effect': "multi-target"
            })
        if self.level >= 3:
            abilities.append({
                'name': "Battle Cry",
                'description': "A rallying shout that boosts the attack power of all allies for one turn.",
                'boost_amount': 5,
                'effect': "buff"
            })
        if self.level >= 4:
            abilities.append({
                'name': "Defensive Stance",
                'description': "Assume a defensive posture, reducing incoming damage for the next turn.",
                'damage_reduction': 5,
                'effect': "damage_reduction"
            })
        if self.level >= 5:
            abilities.append({
                'name': "Whirlwind Attack",
                'description': "A spinning attack that hits all enemies in range, dealing damage to each.",
                'damage': 20,
                'effect': "multi-target"
            })

        return abilities if abilities else None  # Ensure something is always returned


class WizardAbilities:
    def __init__(self, level):
        self.level = level
        self.abilities = self.get_abilities()

    def get_abilities(self):
        abilities = []
        if self.level >= 1:
            abilities.append({
                "name": "Magic Missile",
                "description": "Launches a missile of magical energy that hits automatically.",
                'damage': 12,
                'effect': "auto-hit"
            })
        if self.level >= 2:
            abilities.append({
                'name': "Mage Armor",
                'description': "Surrounds the wizard with a magical force, increasing their defense.",
                'boost_amount': 3,
                'effect': "buff"
            })
        if self.level >= 3:
            abilities.append({
                'name': "Fireball",
                'description': "A powerful explosion of fire that deals area damage to enemies.",
                'damage': 25,
                'effect': "area-of-effect"
            })
        if self.level >= 4:
            abilities.append({
                'name': "Invisibility",
                'description': "Turns the wizard invisible for one turn, allowing them to avoid attacks.",
                'effect': "stealth"
            })
        if self.level >= 5:
            abilities.append({
                'name': "Lightning Bolt",
                'description': "A bolt of lightning that strikes a single target, dealing heavy damage.",
                'damage': 30,
                'effect': "single-target"
            })

        return abilities if abilities else None  # Ensures abilities are returned, or None if no abilities are available


class RogueAbilities:
    def __init__(self, level):
        self.level = level
        self.abilities = self.get_abilities()

    def get_abilities(self):
        abilities = []
        if self.level >= 1:
            abilities.append({
                'name': "Sneak Attack",
                'description': "Deals extra damage when attacking from stealth or "
                               "when an ally is within 5 feet of the target.",
                'damage': 10,
                'effect': "extra damage"
            })
        if self.level >= 2:
            abilities.append({
                'name': "Cunning Action",
                'description': "Allows the rogue to take a bonus action to Dash, Disengage, or Hide.",
                'effect': "bonus action"
            })
        if self.level >= 3:
            abilities.append({
                'name': "Evasion",
                'description': "The rogue can avoid damage from certain area effects, taking no damage on a successful "
                               "Dexterity saving throw.",
                'effect': "damage reduction"
            })
        if self.level >= 4:
            abilities.append({
                'name': "Uncanny Dodge",
                'description': "When an attacker that the rogue can see hits them with an attack, they can use their "
                               "reaction to halve the attack's damage.",
                'effect': "damage reduction"
            })
        if self.level >= 5:
            abilities.append({
                'name': "Assassinate",
                'description': "When attacking a surprised creature, the rogue scores a critical hit.",
                'damage': 20,
                'effect': "critical hit"
            })

        return abilities if abilities else None  # Ensures abilities are returned, or None if no abilities are available

class VoidspawnAscendantAbilities:
    def __init__(self, level):
        self.level = level
        self.abilities = self.get_abilities()

    def get_abilities(self):
        abilities = []
        if self.level >= 1:
            abilities.append({
                'name': "Void Strike",
                'description': "A powerful attack that drains life from enemies.",
                'damage': 10,
                'effect': "drainlife",
                'life_amount': random.randint(5, 20)
            })
        if self.level >= 2:
            abilities.append({
                'name': "Essence of the Void",
                'description': "Regenerates health in cursed or dark areas.",
                'effect': "Regenerate"
            })
        if self.level >= 3:
            abilities.append({
                'name': "Shadow Cloak",
                'description': "Allows you to become invisible in darkness.",
                'effect': "untargetable"
            })
        if self.level >= 4:
            abilities.append({
                'name': "Spectral Minions",
                'description': "Gain one Minion to fight for you for 2 turns",
                'effect': "Minion"
            })
        if self.level >= 5:
            abilities.append({
                'name': "Acendent to the throne",
                'description': "Your stats are now doubled",
                'effect': "super_buff"
            })

        return abilities if abilities else None  # Ensure something is always returned


# Game encounters
boss_monsters = {
    "Ogre": {"hp": 100, "damage": (10, 20), "special_ability": "Smash", "ability_effect": "deal double damage"},
    "Vampire": {"hp": 80, "damage": (8, 15), "special_ability": "Blood Drain", "ability_effect": "heal 10 HP"},
    "Cave Beast": {"hp": 130, "Damage ": (9 - 17), "special_ability": "Wind Wing", "ability_effect": "Defence up"},
    "Bandit King": {"hp": 90, "Damage ": (6 - 20), "special_ability": "Smash", "ability_effect": "deal double damage"}
}


def monster_encounter(player):
    monsters = ["Goblin", "Skeleton", "Wraith"]
    is_boss_encounter = random.random() < 0.1  # 10% chance to encounter a boss
    boss_name = None  # Initialize boss_name
    monster = None  # Initialize monster
    monster_hp = 0  # Initialize monster_hp
    special_ability = None  # Initialize special_ability

    if is_boss_encounter:
        # Choose a random boss monster
        boss_name, boss_stats = random.choice(list(boss_monsters.items()))
        monster_hp = boss_stats["hp"]
        special_ability = boss_stats["special_ability"]  # Assigning the special ability
        print(f"\nA wild {boss_name} appears! It has {monster_hp} HP.")
        return boss_stats
    else:
        # Normal monster encounter
        monster = random.choice(monsters)
        monster_hp = random.randint(30, 50)
        print(f"\nA wild {monster} appears! It has {monster_hp} HP.")

    # Combat loop for either the boss or regular monster
    while monster_hp > 0 and player.hp > 0:
        print(f"\nYour HP: {player.hp}")
        print(f"{boss_name if is_boss_encounter else monster}'s HP: {monster_hp}")

        action = input("What will you do? (attack/spell/abilities/dodge/heal/use item/run): ")

        if action == "attack":
            if player.character_class in ["Fighter", "Rogue","Voidspwan Ascendant"]:
                damage = player.attack()
                monster_hp -= damage
                print(f"You attack the {boss_name if is_boss_encounter else monster} and deal {damage} damage.")
            else:
                print("Wizards cannot attack directly!")

        elif action == "spell":
            if player.character_class == "Wizard" or "Voidspwan Ascendant":
                spell_damage = player.cast_spell()
                monster_hp -= spell_damage
                print(f"You cast a spell and deal {spell_damage} damage.")
            else:
                print("Only Wizards can cast spells!")

        elif action == "dodge":
            if player.dodge():
                print("You dodged the monster's attack!")
                continue
            else:
                print("Failed to dodge!")

        elif action == "abilities":
            abilities = player.get_character_abilities()
            if not abilities or not isinstance(abilities, list):
                print("You have no abilities available at this level.")
                continue

            print("Available abilities:")
            for ability in abilities:
                if isinstance(ability, dict):
                    print(f"- {ability.get('name')}: {ability.get('description')}")

            ability_choice = input("Choose an ability to use: ").strip().lower()
            ability_used = next((ability for ability in abilities if
                                 isinstance(ability, dict) and ability['name'].lower() == ability_choice), None)

            if ability_used:
                # Handle the ability effect
                if 'damage' in ability_used:
                    damage = random.randint(ability_used['damage'] - 5, ability_used['damage'])
                    monster_hp -= damage
                    print(f"You used {ability_used['name']} and dealt {damage} damage.")
                if ability_used.get("effect") == "stun":
                    print(f"The {boss_name if is_boss_encounter else monster} is stunned and cannot attack this turn!")
                    continue  # Skip the monster's turn
                elif ability_used.get("effect") == "buff":
                    player.attack_power += ability_used.get("boost_amount", 0)
                    print(f"You gained a boost in attack power! Your attack power is now {player.attack_power}.")
                elif ability_used.get("effect") == "damage reduction":
                    reduced_damage1 = random.randint(2, 15)
                    print(f"You now have better defence this turn!")
                    player.hp = min(player.hp + reduced_damage1, player.max_hp)
            else:
                print("Invalid ability choice.")

        elif action == "heal":
            player.heal()

        elif action == "use item":
            if not player.inventory:
                print("You have no items to use.")
                continue
            print("Your inventory:")
            for index, item in enumerate(player.inventory):
                print(f"{index + 1}: {item.name} (Effect: {item.effect})")
            item_choice = input("Select an item by number to use: ")
            try:
                item_index = int(item_choice) - 1
                if 0 <= item_index < len(player.inventory):
                    player.use_item(player.inventory[item_index])
                else:
                    print("Invalid item choice.")
            except ValueError:
                print("Please enter a valid number.")
        elif action == "run":
            print("You escaped the encounter!")
            return
        else:
            print("Invalid action, try again!")

        # Monster attacks after player's turn
        if monster_hp > 0:
            if is_boss_encounter:
                boss_name, boss_stats = random.choice(list(boss_monsters.items()))
                monster_hp = boss_stats["hp"]
                special_ability = boss_stats["special_ability"]  # Assigning the special ability
                print(f"\nA wild {boss_name} appears! It has {monster_hp} HP.")
                boss_damage = random.randint(*boss_stats["damage"])
                player.hp -= boss_damage
                print(f"The {boss_name} attacks and deals {boss_damage} damage!")

                chance = random.randint(1, 100)

                if chance <= 30:  # 30% chance to trigger special ability
                    print(f"The {boss_name} uses {special_ability}!")
                    if special_ability == "Smash":
                        # Smash does double damage
                        damage = boss_damage * 2
                        player.hp -= damage
                        print(f"The {boss_name} deals double damage: {damage}!")
                    elif special_ability == "Blood Drain":
                        # Blood Drain damages player and heals the boss
                        player.hp -= boss_damage
                        monster_hp += 10  # Heal boss by 10 HP
                        print(f"The {boss_name} drains your life, healing itself by 10 HP!")
                    elif special_ability == "Wind Wing":
                        # Wind Wing reduces player's damage output for a few turns
                        reduced_damage = random.randint(2, 7)
                        print(f"The {boss_name}'s Wind Wing softens your blow, reducing damage by {reduced_damage}.")
                        monster_hp += reduced_damage
                    else:
                        print(f"The {boss_name} tried to use a special ability, but nothing happened.")
                else:
                    # 70% chance for a normal attack
                    print(f"The {boss_name} attacks normally!")
                    player.hp -= boss_damage
                    print(f"The {boss_name} deals {boss_damage} damage to {player.name}!")
            else:
                monster_damage = random.randint(5, 15)
                player.hp -= monster_damage
                print(f"The {monster} attacks and deals {monster_damage} damage!")

    # Check the outcome of the encounter
    if player.hp > 0:
        print(f"\nYou defeated the {boss_name if is_boss_encounter else monster}!")
        xp_reward = random.randint(100, 200) if is_boss_encounter else random.randint(50, 100)
        player.gain_xp(xp_reward)
        gold_reward = random.randint(300, 500) if is_boss_encounter else random.randint(20, 150)
        player.gold += gold_reward  # Add the gold to the player's total gold
        print(f"You earned {xp_reward} XP for defeating the {boss_name if is_boss_encounter else monster}!")
        print(f"You have {player.xp} XP")
        print(f"You have earned {gold_reward} Gold")
        print(f"You have {player.gold} Gold ")
    else:
        print(f"\nYou were defeated by the {boss_name if is_boss_encounter else monster}... Game over.")

# Story Game encounters
story_boss_monsters = {
            "Corrupted Villager": {"hp": 150, "damage": (5, 15), "special_ability": "Smash",
                                   "ability_effect": "deal double damage"},
            "Temple Guardian": {"hp": 100, "damage": (10, 15), "special_ability": "Life",
                                "ability_effect": "heal 20 HP"},
            "Frost Shades": {"hp": 100, "damage": (10, 15), "special_ability": "Frost",
                                "ability_effect": "Freeze player for 1 turn"},
            "Corrupted Monk": {"hp": 100, "damage": (10, 15), "special_ability": "Life",
                                "ability_effect": "heal 20 HP"},

            "Giant Worm": {"hp": 200, "damage": (9, 17), "special_ability": "SandStorm",
                           "ability_effect": "deal double damage"},
            "Shadow Stalkers": {"hp": 150, "damage": (10, 15), "special_ability":
                "Shadow", "ability_effect": "dodge players attack"},
            "Spectral Knight": {"hp": 200, "damage": (10, 15), "special_ability":
                "SoulSlash", "ability_effect": "deal double damage"},

            "Abyss Warden": {"hp": 300, "damage": (15, 20), "special_ability":
                "Cleaver", "ability_effect": "deals more slashing damage"},

            "Corrupted High Priestess": {"hp": 350, "damage": (20, 25), "special_ability":
                "Light", "ability_effect": "Pillers of light come down dealing damage and healing  the boss"},

            "Children of the void": {
                "hp": 150,
                "damage": (15, 25),
                "special_ability": "void_step",
                "ability_effect": "Teleports behind the player, dodging the next attack and dealing double damage on "
                                  "its next turn."
            },
            "VoidSpawn": {
                "hp": 750,
                "damage": (25, 40),
                "special_abilities": {
                    "Eternal Dread": {
                        "type": "passive",
                        "effect": "reduce player max HP by 10% every 3 turns",
                        "timer": 3,
                        "counter": 0
                    },
                    "Spectral Army": {
                        "type": "active",
                        "effect": "summon 2 Spectral Minions",
                        "cooldown": 5,
                        "remaining_cooldown": 0
                    }
                }
            }
        }

def story_boss_encounter(player, boss_name):
    # Retrieve specific boss by name
    boss_stats = story_boss_monsters.get(boss_name)
    if not boss_stats:
        print("The specified boss does not exist.")
        return

    monster_hp = boss_stats["hp"]
    special_ability = boss_stats["special_ability"]

    print(f"\n{boss_name} appears! They have {monster_hp} HP.")

    # Combat loop specifically for boss encounters
    while monster_hp > 0 and player.hp > 0:
        print(f"\nYour HP: {player.hp}")
        print(f"{boss_name}'s HP: {monster_hp}")

        action = input("What will you do? (attack/spell/abilities/dodge/heal/use item/run): ")

        if action == "attack":
            if player.character_class in ["Fighter", "Rogue"]:
                damage = player.attack()
                monster_hp -= damage
                print(f"You attack the {boss_name} and deal {damage} damage.")
            else:
                print("Wizards cannot attack directly!")

        elif action == "spell":
            if player.character_class == "Wizard":
                spell_damage = player.cast_spell()
                monster_hp -= spell_damage
                print(f"You cast a spell and deal {spell_damage} damage.")
            else:
                print("Only Wizards can cast spells!")

        elif action == "dodge":
            if player.dodge():
                print("You dodged the monster's attack!")
                continue
            else:
                print("Failed to dodge!")

        elif action == "abilities":
            abilities = player.get_character_abilities()
            if not abilities or not isinstance(abilities, list):
                print("You have no abilities available at this level.")
                continue

            print("Available abilities:")
            for ability in abilities:
                if isinstance(ability, dict):
                    print(f"- {ability.get('name')}: {ability.get('description')}")

            ability_choice = input("Choose an ability to use: ").strip().lower()
            ability_used = next((ability for ability in abilities if
                                 isinstance(ability, dict) and ability['name'].lower() == ability_choice), None)

            if ability_used:
                if 'damage' in ability_used:
                    damage = random.randint(ability_used['damage'] - 5, ability_used['damage'])
                    monster_hp -= damage
                    print(f"You used {ability_used['name']} and dealt {damage} damage.")
                if ability_used.get("effect") == "stun":
                    print(f"The {boss_name} is stunned and cannot attack this turn!")
                    continue
                elif ability_used.get("effect") == "buff":
                    player.attack_power += ability_used.get("boost_amount", 0)
                    print(f"You gained a boost in attack power! Your attack power is now {player.attack_power}.")
                elif ability_used.get("effect") == "damage reduction":
                    reduced_damage1 = random.randint(2, 15)
                    print(f"You now have better defense this turn!")
                    player.hp = min(player.hp + reduced_damage1, player.max_hp)
            else:
                print("Invalid ability choice.")

        elif action == "heal":
            player.heal()

        elif action == "use item":
            if not player.inventory:
                print("You have no items to use.")
                continue
            print("Your inventory:")
            for index, item in enumerate(player.inventory):
                print(f"{index + 1}: {item.name} (Effect: {item.effect})")
            item_choice = input("Select an item by number to use: ")
            try:
                item_index = int(item_choice) - 1
                if 0 <= item_index < len(player.inventory):
                    player.use_item(player.inventory[item_index])
                else:
                    print("Invalid item choice.")
            except ValueError:
                print("Please enter a valid number.")
        elif action == "run":
            print("You cannot run from a boss fight!")
        else:
            print("Invalid action, try again!")

        # Boss attacks after player's turn
        if monster_hp > 0:
            boss_damage = random.randint(*boss_stats["damage"])
            player.hp -= boss_damage
            print(f"The {boss_name} attacks and deals {boss_damage} damage!")

            chance = random.randint(1, 100)
            if chance <= 20:  # 20% chance to trigger special ability
                print(f"The {boss_name} uses {special_ability}!")
                if special_ability == "Smash":
                    damage = boss_damage * 2
                    player.hp -= damage
                    print(f"The {boss_name} deals double damage: {damage}!")
                elif special_ability == "Life":
                    monster_hp += 20
                    print(f"The {boss_name} heals itself by 20 HP!")
                elif special_ability == "SandStorm":
                    reduced_damage = random.randint(2, 7)
                    print(f"The {boss_name}'s SandStorm reduces your incoming damage by {reduced_damage} this turn.")
                elif special_ability == "void_step":
                    monster_hp += boss_damage
                    player.hp -= boss_damage * 2
                    print(f"The {boss_name} teleports behind you, dodging your next attack and dealing double damage!")
                elif special_ability == "Shadow":
                    monster_hp += boss_damage
                    print(f"The {boss_name} Disappears into the darkness, dodging your next attack!")
                elif special_ability == "Cleaver":
                    player.hp -= boss_damage * 1.5
                    print(f"The {boss_name} Uses his cleaver to attack!")
                elif special_ability == "Light":
                    monster_hp += random.randint(10, 50)
                    player.hp -= boss_damage * 1.5
                    print(f"The {boss_name} Conjures a pillar of light from the heavens, Healing herself and damaging "
                          f"you!")
                elif special_ability == "Frost":
                    print(f"The {boss_name} Freezes you so he gets to attack again!")
                    # Boss attacks after player's turn
                    if monster_hp > 0:
                        boss_damage = random.randint(*boss_stats["damage"])
                        player.hp -= boss_damage
                        print(f"The {boss_name} attacks and deals {boss_damage} damage!")
                elif special_ability == "SoulSlash":
                    damage = boss_damage * 2
                    player.hp -= damage
                    print(f"The {boss_name} deals double damage: {damage}!")
    # Check the outcome of the encounter
    if player.hp > 0:
        print(f"\nYou defeated the {boss_name}!")
        xp_reward = random.randint(100, 200)
        player.gain_xp(xp_reward)
        gold_reward = random.randint(300, 500)
        player.gold += gold_reward
        print(f"You earned {xp_reward} XP and {gold_reward} gold for defeating the {boss_name}!")
    else:
        print(f"\nYou were defeated by the {boss_name}... Game over.")


def story_monster_encounter(player, monster_name):
    # Define monsters and their HP range
    monsters = {
        "Goblin": (30, 40),
        "Skeleton": (35, 45),
        "Wraith": (40, 50),
        "Bandit": (40, 50),
        "Wild Beasts": (25, 30),
        "Shadow": (25, 35),
        "Voidspawn Minion": (15, 20)
    }

    # Validate if the specified monster is available
    if monster_name not in monsters:
        print("Invalid monster name. Please choose a valid monster.")
        return

    # Set up the selected monster
    monster_hp = random.randint(*monsters[monster_name])
    print(f"\nA wild {monster_name} appears! It has {monster_hp} HP.")

    # Combat loop for the regular monster
    while monster_hp > 0 and player.hp > 0:
        print(f"\nYour HP: {player.hp}")
        print(f"{monster_name}'s HP: {monster_hp}")

        action = input("What will you do? (attack/spell/abilities/dodge/heal/use item/run): ")

        if action == "attack":
            if player.character_class in ["Fighter", "Rogue"]:
                damage = player.attack()
                monster_hp -= damage
                print(f"You attack the {monster_name} and deal {damage} damage.")
            else:
                print("Wizards cannot attack directly!")

        elif action == "spell":
            if player.character_class == "Wizard":
                spell_damage = player.cast_spell()
                monster_hp -= spell_damage
                print(f"You cast a spell and deal {spell_damage} damage.")
            else:
                print("Only Wizards can cast spells!")

        elif action == "dodge":
            if player.dodge():
                print("You dodged the monster's attack!")
                continue
            else:
                print("Failed to dodge!")

        elif action == "abilities":
            abilities = player.get_character_abilities()
            if not abilities or not isinstance(abilities, list):
                print("You have no abilities available at this level.")
                continue

            print("Available abilities:")
            for ability in abilities:
                if isinstance(ability, dict):
                    print(f"- {ability.get('name')}: {ability.get('description')}")

            ability_choice = input("Choose an ability to use: ").strip().lower()
            ability_used = next((ability for ability in abilities if
                                 isinstance(ability, dict) and ability['name'].lower() == ability_choice), None)

            if ability_used:
                if 'damage' in ability_used:
                    damage = random.randint(ability_used['damage'] - 5, ability_used['damage'])
                    monster_hp -= damage
                    print(f"You used {ability_used['name']} and dealt {damage} damage.")
                if ability_used.get("effect") == "stun":
                    print(f"The {monster_name} is stunned and cannot attack this turn!")
                    continue
                elif ability_used.get("effect") == "buff":
                    player.attack_power += ability_used.get("boost_amount", 0)
                    print(f"You gained a boost in attack power! Your attack power is now {player.attack_power}.")
                elif ability_used.get("effect") == "damage reduction":
                    reduced_damage = random.randint(2, 15)
                    print(f"You now have better defense this turn!")
                    player.hp = min(player.hp + reducedamage, player.max_hp)
            else:
                print("Invalid ability choice.")

        elif action == "heal":
            player.heal()

        elif action == "use item":
            if not player.inventory:
                print("You have no items to use.")
                continue
            print("Your inventory:")
            for index, item in enumerate(player.inventory):
                print(f"{index + 1}: {item.name} (Effect: {item.effect})")
            item_choice = input("Select an item by number to use: ")
            try:
                item_index = int(item_choice) - 1
                if 0 <= item_index < len(player.inventory):
                    player.use_item(player.inventory[item_index])
                else:
                    print("Invalid item choice.")
            except ValueError:
                print("Please enter a valid number.")
        elif action == "run":
            print("You escaped the encounter!")
            return
        else:
            print("Invalid action, try again!")

        # Monster attacks after player's turn
        if monster_hp > 0:
            monster_damage = random.randint(5, 15)
            player.hp -= monster_damage
            print(f"The {monster_name} attacks and deals {monster_damage} damage!")

    # Check the outcome of the encounter
    if player.hp > 0:
        print(f"\nYou defeated the {monster_name}!")
        xp_reward = random.randint(50, 100)
        player.gain_xp(xp_reward)
        gold_reward = random.randint(20, 150)
        player.gold += gold_reward
        print(f"You earned {xp_reward} XP and {gold_reward} Gold!")
        print(f"Total XP: {player.xp}, Total Gold: {player.gold}")
    else:
        print(f"\nYou were defeated by the {monster_name}... Game over.")

# Random area generation
def random_area():
    areas = ["town", "forest", "cave", "road", "ruins"]
    return random.choice(areas) if random.random() < 0.90 else None  # 90% chance to find an area


# Random item generation
def find_item():
    items = [
        Item("Health Potion", "heal", 20),
        Item("Attack Elixir", "attack_boost", 30),
        Item("Leather Armor", "armor", 50),
        Item("Longsword", "attack", 40),
    ]

    # 5% chance to find an item
    if random.random() < 0.05:
        found_item = random.choice(items)
        print(f"You found a {found_item.name}!")
        return found_item
    else:
        return None


# Quest class to manage quests
class Quest:
    def __init__(self, name, description, objective, reward):
        self.name = name
        self.description = description
        self.objective = objective
        self.reward = reward
        self.is_completed = False

    def __str__(self):
        return f"{self.name}: {self.description}"

    def complete_quest(self, player):
        if not self.is_completed:
            print(f"Quest '{self.name}' completed!")
            player.inventory.append(self.reward)
            player.gain_xp(100)  # Give XP as part of the reward
            print(f"You received {self.reward.name} and 100 XP!")
            self.is_completed = True


# Quests
quests = [
    Quest("Forest Treasure", "Find the hidden treasure in the forest.", "find_treasure",
          Item("Forest Treasure", "none", 0)),
    Quest("Defeat the Cave Beast", "Defeat the monster lurking in the cave.", "defeat_cave_monster",
          Item("Cave Beast Fang", "attack", 5)),
    Quest("Herb Gathering", "Collect healing herbs from the forest.", "gather_herbs",
          Item("Healing Herb", "heal", 15)),
    Quest("Bandit King", "Defeat the Bandit King hiding in the ruins.", "defeat_bandit_king",
          Item("Bandit King's Sword", "attack", 10)),
    Quest("Ancient Ruins Discovery", "Discover the secrets of the ancient ruins.", "explore_ruins",
          Item("Ancient Scroll", "none", 0)),
]

# NPC Definitions
npc_merchant = NPC(
    name="Balinor",
    role="Merchant",
    dialogue={
        "Who are you?": "I am Balinor, a merchant selling rare goods.",
        "Anything interesting around here?": "I’ve heard rumors of a hidden treasure nearby."
    },
    trade_items=[
        {"name": "Health Potion", "price": 50},
        {"name": "Magic Scroll", "price": 100}
    ],
    quest={
        "description": "Retrieve the lost amulet from the Goblin Cave.",
        "reward": "100 gold and a magic sword"
    }
)

npc_traveler = NPC(
    name="Thorin",
    role="Traveler",
    dialogue={
        "Who are you?": "I am Thorin, just passing through these lands.",
        "Have you seen anything unusual?": "I saw a shadowy figure lurking by the old ruins."
    },
    quest={
        "description": "Defeat the bandits terrorizing the forest.",
        "reward": "A rare weapon"
    }
)

npc_wandering_mage = NPC(
    name="Lysandra",
    role="Wandering Mage",
    dialogue={
        "Who are you?": "I am Lysandra, a mage traveling these lands in search of magical artifacts.",
        "What do you seek?": "I am looking for the Crystal of Light, lost deep in the woods."
    }
)


def main_story1(player):
    """Handles the main storyline for Chapter 1."""
    global Story
    Story = True  # Set to true when the main story is active

    print("\n--- Chapter 1: Whispers in the Shadows ---")
    print("You find yourself in the quaint town of Eldergrove,")
    print("where rumors swirl about a dark force threatening the region.")
    print("As you sit in the local inn, the smell of roasted meat and ale fills the air.")

    # Option for the player to listen for rumors
    print("\nYou overhear some townsfolk talking...")
    print("1. Approach the barmaid and ask about the rumors.")
    print("2. Eavesdrop on the nearby table of adventurers.")
    print("3. Ignore the rumors and leave the inn.")

    choice = input("Choose an option (1-3): ")

    if choice == "1":
        print("\nYou approach the barmaid.")
        print("She seems hesitant but eventually tells you, 'There's been sightings of strange shadows in the woods.'")
        print("It seems like something sinister is at play...")
        # Continue the story based on this choice
        investigate_shadows(player)
    elif choice == "2":
        print("\nYou lean in closer to the adventurers.")
        print("They speak of a village nearby that was attacked by shadowy creatures.")
        print("One of them says, 'We need to do something before it spreads!'")
        # Continue the story based on this choice
        investigate_village(player)
    elif choice == "3":
        print("\nYou decide to ignore the rumors.")
        print("As you leave the inn, a chill runs down your spine...")
        print("Perhaps it would be wise to investigate further after all.")
        main_story(player)  # Loop back to the beginning of the chapter
    else:
        print("Invalid choice. Please try again.")
        main_story(player)  # Loop back to the beginning of the chapter


def investigate_shadows(player):
    """Handles the storyline related to investigating shadows."""
    print("\nYou decide to investigate the strange shadows...")
    print("With your resolve strengthened, you head towards the woods.")
    print("As you enter the darkened forest, you hear whispers echoing through the trees.")

    # Provide more choices and story progression
    print("1. Follow the whispers deeper into the woods.")
    print("2. Set up camp and prepare for whatever might come.")

    choice = input("Choose an option (1-2): ")

    if choice == "1":
        print("\nYou follow the whispers...")
        print("Suddenly, shadowy figures emerge from the trees!")
        # Continue the story with an encounter
        encounter_shadows(player)
    elif choice == "2":
        print("\nYou decide to set up camp.")
        print("As night falls, you hear the whispers grow louder...")
        # Continue with a different outcome
        night_encounter(player)


def investigate_village(player):
    """Handles the storyline related to investigating the village."""
    print("\nYou gather your gear and make your way to the village.")
    print("Upon arrival, you find the place in disarray; villagers are in a panic.")

    # Provide choices for interaction in the village
    print("1. Speak to the village elder.")
    print("2. Check for any wounded villagers.")

    choice = input("Choose an option (1-2): ")

    if choice == "1":
        print("\nYou approach the elder.")
        print("'We need your help!' she pleads. 'The shadows have taken our livestock. They come from the ruins.'")
        # Continue with a quest from the elder
        ruins_encounter(player)
    elif choice == "2":
        print("\nYou tend to the wounded.")
        print("A villager whispers, 'The shadows come from the old ruins to the east.'")
        player.gain_xp(50)
        # Continue the story with a new location
        ruins_encounter(player)


# You can define additional functions for encounters, quests, etc.
def encounter_shadows(player):
    """Handles the encounter with shadowy figures."""
    print("\nThe shadows converge around you, ready to attack!")
    monster_encounter(player)
    if player.hp <= 0:
        print("The Shadows retreat to some ruins")
        ruins_encounter(player)

def night_encounter(player):
    """Handles an encounter during the night in the camp."""
    print("\nIn the darkness, a shadow creeps closer to your camp...")
    print("As you prepare for battle the shadow moves past you to the east")
    print("and you can see smoke coming from the west")
    Choose = input("Do you (Go/Stay): ").lower()
    if Choose == "go":
        investigate_village(player)
    elif Choose == "Stay":
        print("You stay and prepare for sleep")
        print("You are awaken to the sound of villagers screaming and Shadows flying by.")
        print("In the distance you see some ruins.")
        print("Determined to save the children and women, you run to the old ruins.")
        ruins_encounter(player)

def ruins_encounter(player):
    """Handles the main encounter in the ruins."""
    print("\nYou arrive at the ancient ruins.")
    print("Strange symbols adorn the walls, and an eerie silence surrounds you...")
    print("As you walk the halls, you notice flickering lights coming from a room.")

    # Player's choice to ignore or investigate
    pick = input("Do you ignore it or go to the room? (ignore/go): ").lower()

    if pick == "ignore":
        print("\nYou continue walking the halls, trying to avoid whatever lies ahead.")
        print("Suddenly, a monster appears out of the shadows!")
        monster_encounter(player)  # Call the function that handles combat
        monster_encounter(player)
        if player.hp <= 0:
            main_story(player)
        else:
            print("As you eliminate the shadow a man walks up behind you")
            print("'My name is Calvin, and I swear, I am not your enemy.'")
            print("'Let's go to town and I'll tell you more.'")
            print("As you enter the town of Glimmereach you and Calvin go to the local tavern")
            print("'Alright who are you', you ask")
            print("'I'm an adventurer like you.'")
            print("'And I've come here to take down the VoidSpawn'")
            main_story2(player)
    elif pick == "go":
        print("\nYou enter a room illuminated by a singular flickering torch, floating mysteriously in the air.")
        print("Scattered across the floor are bodies that appear to have been killed recently.")

        # Second choice in the room
        further_pick = input("What do you do? (inspect the bodies/look around/grab the torch): ").lower()

        if further_pick == "inspect the bodies":
            print("\nYou kneel down cautiously to inspect the bodies.")
            print("Each corpse bears a strange birthmark, identical in appearance.")
            print("Suddenly, you hear a voice from behind you...")
            print("One of the bodies sits up and speaks: 'Hello! Please, don't attack me!'")
            print("'My name is Calvin, and I swear, I am not your enemy.'")

            # Player's response
            speak = input("What do you tell the man? (how do I know you're not evil(1)/alright(2)): ").lower()

            if speak == "1":
                print("\n'Look...' Calvin says, lifting his shirt to reveal the same birthmark as the others.")
                print("Surprised, you realize it's the same mark on the corpses.")
                print("'Yeah, and you have one too,' Calvin says, pointing to the back of your neck.")

            elif speak == "2":
                print("\n'Is that all?' Calvin says, surprised by your quick trust.")
                print("'You give your trust too easily,' he remarks.")
                print("'Would you rather I kill you?' you ask, annoyed.")
                print("'No, no, no! See? I’m good!' Calvin insists, showing you his birthmark.")
                print("'Wait... you have one as well,' you say, startled.")
                print("'Yeah, and so do you,' Calvin says, pointing to the back of your neck.")

            # Next question from the player
            speak1 = input("What do you ask? (what is it/I don’t believe you): ").lower()

            if speak1 == "what is it":
                print("\nCalvin explains, 'It's the mark of the Fatebound.'")
                print("'Who are the Fatebound?' you ask.")
                print("'They're the creators of this place, ancient beings tied to fate itself.'")
                print("'Come on, let's go to town.'")
                main_story2(player)

            elif speak1 == "i dont believe you":
                print("\n'Fine, don't believe me,' Calvin says with a shrug.")
                print("'I’m trying to help, but you just can’t please everyone.'")
                print("As the tension rises, a hostile enemy appears from the shadows!")
                monster_encounter(player)
                if player.hp <= 0:
                    main_story(player)
                else:
                    print("'Come on, let's go to town.'")
                    print("When you arrive to the village of Glimmereach you and the man walk to the local tavern.")
                    print("'Alright who, exactly are you', you ask")
                    print("'My name is Calvin. I'm an adventurer like you.'")
                    print("'And I've come here to take down the VoidSpawn'")
                    main_story2(player)
        elif further_pick == "look around":
            print("\nYou examine the room carefully, looking for clues or hidden dangers.")
            print("The flickering torch casts ominous shadows, but nothing seems out of place.")
            print("Suddenly, an enemy attacks from the darkness!")
            monster_encounter(player)
            if player.hp <= 0:
                main_story(player)
            else:
                print("As you eliminate the shadow a man walks up behind you")
                print("'My name is Calvin, and I swear, I am not your enemy.'")

            # Player's response
            speak = input("What do you tell the man? (how do I know you're not evil(1)/alright(2)): ").lower()

            if speak == "1":
                print("\n'Look...' Calvin says, lifting his shirt to reveal the same birthmark as the others.")
                print("Surprised, you realize it's the same mark on the corpses.")
                print("'Yeah, and you have one too,' Calvin says, pointing to the back of your neck.")

            elif speak == "2":
                print("\n'Is that all?' Calvin says, surprised by your quick trust.")
                print("'You give your trust too easily,' he remarks.")
                print("'Would you rather I kill you?' you ask, annoyed.")
                print("'No, no, no! See? I’m good!' Calvin insists, showing you his birthmark.")
                print("'Wait... you have one as well,' you say, startled.")
                print("'Yeah, and so do you,' Calvin says, pointing to the back of your neck.")

            # Next question from the player
            speak1 = input("What do you ask? (what is it/I don’t believe you): ").lower()

            if speak1 == "what is it":
                print("\nCalvin explains, 'It's the mark of the Fatebound.'")
                print("'Who are the Fatebound?' you ask.")
                print("'They're the creators of this place, ancient beings tied to fate itself.'")
                print("'We should go to town'")
                print("'This place isn't safe.' Calvin says")
                print("When you arrive to the village of Glimmereach you and the man walk to the local tavern.")
                print("'Alright really who are you', you ask")
                print("'my name is Calvin. I'm an adventurer like you.'")
                print("'And I've come here to take down the VoidSpawn'")
            elif speak1 == "i dont believe you":
                print("\n'Fine, don't believe me,' Calvin says with a shrug.")
                print("'I’m trying to help, but you just can’t please everyone.'")
                print("'But please trust me and go to town we don't have much time")
                print("'Fine', you say sharply.'We'll go")
                print("When you arrive to the village of Glimmereach you and the man walk to the local tavern.")
                print("'Alright really who are you', you ask")
                print("'my name is Calvin. I'm an adventurer like you.'")
                print("'And I've come here to take down the VoidSpawn'")
        elif further_pick == "grab the torch":
            print("\nYou reach out to grab the torch.")
            print("As soon as your hand touches it, the entire room goes dark!")
            print("'Put it back!'")
            print("'You've Doomed us!'")
            print("As the man says this a portal in the hole forms.")
            print("'Come, this way.' The man grabs your arm and drags you out of the room and into the forest outside.")
            print("As your outside you see a beam of blackish, purplish light that shoots up into the air.")
            print("'Okay we need to get out of here.' The man says determined.")
            speak = input("What do you say(No/Who are you): ").lower()
            if speak == "no":
                print("'Come on, we don't have time.'")
                print("'No, I don't even know who you are.' You say")
                print("'Fine... Look'. The man rolls up his sleeve to show you a birthmark.")
                print("Annoyed he says, 'You also have one")
                print("'there their because our ancestors were tied to Fate itself'.")
                print("'Now are you coming'.")
                print("Finally you say, 'alright fine but when we get there you have a lot of explaining to do'.")
                print("When you arrive to the village of Glimmereach you and the man walk to the local tavern.")
                print("'Alright who are you', you ask")
                print("'my name is Calvin. I'm an adventurer like you.'")
                print("'And I've come here to take down the VoidSpawn'")
            if speak == "who are you":
                print("I'm Calvin")
                print("'And I'll tell you more when we get to town.'")
                print("When you arrive to the village of Glimmereach you and the man walk to the local tavern.")
                print("'Alright who are you', you ask")
                print("'my name is Calvin. I'm an adventurer like you.'")
                print("'And I've come here to take down the VoidSpawn'")
                player.gain_xp(200)
                main_story2(player)

    else:
        print("Invalid input. Please try again.")
        ruins_encounter(player)
def main_story2(player):
    print("\n--- Chapter 2: The Call of The Past ---")
    print("----------------Part 1-----------------")
    print("After learning about the VoidSpawn you decide you need to learn more.")
    Choose = input("Do you go to the library(1) or ask around(2)")
    if Choose == "1":
        print("You tell Calvin you'll be back")
        print("As you find your way to the library you see the town lively with activity.")
        print("In the library you find stacks and stacks of books and rows and rows of shelf's.")
        print("As you search for anything related to the VoidSpawn you see a book lyered with dust.")
        print("As you pick it up you see the title you read.")
        print("\n'The DarkBorn Curse'")
        read1 = input("Do you want to read Chapter 1 (yes/no)? ").lower()

        if read1 == "yes":
            print("\nChapter 1: The Darkborn Prophecy")
            print("Long ago, an ancient prophecy spoke of a being")
            print("born from shadows—the Voidspawn. Created from the")
            print("remnants of forbidden magic, it was said to be a")
            print("creature that could consume souls and twist them")
            print("into dark energy. The Voidspawn was bound to be an")
            print("eternal curse on those who sought to wield powers beyond")
            print("mortal understanding.")

            read2 = input("Do you want to read Chapter 2 (yes/no)? ").lower()
            if read2 == "yes":
                print("\nChapter 2: The First Shadow")
                print("In the early days, a group of powerful sorcerers attempted")
                print("to create an entity capable of protecting their realm.")
                print("However, their ritual went horribly wrong, and instead")
                print("they created the Voidspawn, a dark entity with an insatiable")
                print("hunger for souls, turning peaceful spirits into dark phantoms.")

                read3 = input("Do you want to read Chapter 3 (yes/no)? ").lower()
                if read3 == "yes":
                    print("\nChapter 3: The Soulstone Binding")
                    print("To stop the Voidspawn, ancient priests crafted the Soulstone.")
                    print("In a desperate ritual, they managed to bind the Voidspawn,")
                    print("splitting the Soulstone into pieces and scattering them.")
                    print("Though sealed, the Voidspawn’s dark energy still leaked out,")
                    print("cursing those who came into contact with the fragments.")

                    read4 = input("Do you want to read Chapter 4 (yes/no)? ").lower()
                    if read4 == "yes":
                        print("\nChapter 4: The Curse of the Soulbound")
                        print("The Voidspawn’s influence lingered, creating the 'Soulbound'—")
                        print("those cursed by fragments of the Soulstone, who were haunted")
                        print("by whispers and visions of the Voidspawn’s prison, driven by")
                        print("an unnatural pull toward its dark energy.")

                        read5 = input("Do you want to read Chapter 5 (yes/no)? ").lower()
                        if read5 == "yes":
                            print("\nChapter 5: The Rise of the Cult of Shadows")
                            print("A dark cult known as the Cult of Shadows formed over time,")
                            print("worshipping the Voidspawn. They sought the Soulstone fragments")
                            print("to release their master, believing in its promise of power.")
                            print("But the Voidspawn desired only to use them, caring nothing for")
                            print("their loyalty.")

                            read6 = input("Do you want to read Chapter 6 (yes/no)? ").lower()
                            if read6 == "yes":
                                print("\nChapter 6: Legends of the Voidborne War")
                                print("Ancient records tell of the Voidborne War, a massive conflict")
                                print("where the armies of mortals fought against the Voidspawn and")
                                print("its spectral followers. Though victorious, the mortals paid a")
                                print("heavy price, and many lands remained scarred by dark magic.")
                                print("The survivors decreed that the knowledge of the Voidspawn be")
                                print("hidden away, fearing it would once again bring devastation.")

                                read7 = input("Do you want to read Chapter 7 (yes/no)? ").lower()
                                if read7 == "yes":
                                    print("\nChapter 7: Whispers of the Unbound")
                                    print("Rumors began circulating about an event known as the 'Unbinding,'")
                                    print("a disaster that could occur if the Voidspawn’s fragments were")
                                    print("reunited. According to lore, the creature would rise more powerful")
                                    print("than before, consuming entire villages, and perhaps even worlds.")
                                    print("The legend warns of an eternal night, a curse so potent that")
                                    print("nothing could escape it.")
                                    print("\nCongrats! You read it all here is 200 xp")
                                    player.gain_xp(200)


                                else:
                                    print("\nYou chose not to continue to Chapter 7.")
                            else:
                                print("\nYou chose not to continue to Chapter 6.")
                        else:
                            print("\nYou chose not to continue to Chapter 5.")
                    else:
                        print("\nYou chose not to continue to Chapter 4.")
                else:
                    print("\nYou chose not to continue to Chapter 3.")
            else:
                print("\nYou chose not to continue to Chapter 2.")
            print("Now armed with this knowledge you find someone who can tell you more.")
        else:
            print("\nYou chose not to read 'The DarkBorn Curse'.")
            print("Not wanting to see the book you try to find someone who can tell you more.")
        town_encounter(player)
    if Choose == "2":
        print("You tell Calvin you'll be back")
        print("As you find your way to find someone you see the town lively with activity.")
        print("Merchants everywhere and people dancing in town square.")
        town_encounter(player)
    else:
        print("Not valid. pick 1 or 2")
        main_story2(player)

def town_encounter(player):
    print("You come across a group of townsfolk gathered around an elderly man speaking in hushed tones.")
    print("He seems to be telling a story about the old legends surrounding the curse.")

    listen = input("Do you want to listen to the man's story? (yes/no) ").lower()
    if listen == "yes":
        print("\nThe Elderly Man: 'Long ago, the Fatebound protected this land from a darkness unlike any other.")
        print("Their souls were bound by a sacred duty, yet some believe their power attracted a terrible curse.")
        print("The VoidSpawn, a creature born from forbidden magic, has haunted these lands ever since.'")

        print("The man glances at you and lowers his voice even more.")
        print("Elderly Man: 'If you truly seek answers, you should go to the abandoned temple in the mountains.'")
        print("'The path is dangerous and frightening, not many have made it out alive.'")
        print("The old man tells of a map that can get someone there, but it's lost in the NeverEnding forest.")
        village_encounter(player)
    else:
        print("\nYou decide not to listen to the man and continue wandering the town.")
        print("Without any solid leads, you find yourself wondering if you should have listened.")
        village_encounter(player)

def village_encounter(player):
    print("\nAs you return to the tavern, the sky begins to darken unnaturally.")
    print("The once-bustling village square is now a scene of chaos. Villagers scatter, screaming in terror.")
    print("Suddenly, a figure hurtles through the air—a villager, but twisted, as if possessed.")
    print("Calvin rushes up behind you, his face pale. 'What's going on?' he gasps.")
    print("'I leave you alone for five minutes, and all Hell breaks loose?'")
    print("The possessed villager convulses violently, twisting and writhing, his limbs contorting in ways that defy nature.")
    print("Before your horrified eyes, he transforms, turning inside out to reveal a monstrous, corrupted form.\n")
    story_boss_encounter(player, "Corrupted Villager")
    if player.hp <= 0:
        village_encounter(player)
    else:
        Save_Town1(player)

def Save_Town1(player):
    print("\nThe Corrupted Villager slumps to the ground, defeated.")
    print("In his final, ragged breaths, he murmurs in a voice not his own:")
    print("'He's coming... and there's nothing you can do to stop it.'")
    print("A chilling laugh escapes his lips, even as his body grows still.")
    print("'DARKNESS IS COMING, AND YOU PEASANTS WILL DIE AT THE HANDS OF-!!!'")
    print("The villager's twisted form collapses with a final thud, leaving an eerie silence in his wake.\n")
    player.gain_xp(300)
    chap2part2(player)


def chap2part2(player):
    print("\n--- Chapter 2: The Call of The Past ---")
    print("----------------Part 2-----------------")
    print("'What on earth just happened?' you say with a stressful tone.")
    print("'We can't wait any longer,' Calvin replies, worry etched on his face.")
    print("'Life as we know it is going to turn into chaos if we don't stop this monster.'")
    print("Finally you say, 'I've heard of a lost map that can lead us to the temple where the VoidSpawn was created.'")
    print("After hearing this, Calvin adds, 'I have an idea, but we might need to split up.'")
    print(
        "'One of us should go after the map and investigate the temple, while the other heads to the Kingdom of "
        "Salivra.'")

    choice1 = input("Where do you want to go? (The Temple(1)/Salivra(2)): ")

    if choice1 == "1":
        print("'Alright, I'll go to the Temple, and you head to the Capitol,' you say.")
        print("After making your plans, you both decide to set out on your respective journeys.")
        map_retrieval(player)  # First, retrieve the map

    elif choice1 == "2":
        print("'I'll go to Salivra, and you should go to the temple,' Calvin replies.")
        print("'Let's meet back here in 10 days.'")
        kingdom_journey(player)  # Proceed with the journey to Salivra


def map_retrieval(player):
    print("\nYou set out to find the lost map, hoping it will guide you to the temple.")
    print("Your journey takes you through dense forests and treacherous paths.")
    print("Finally, you reach an old sage's hut, rumored to hold knowledge of the map's location.")

    choice = input("Do you want to knock on the door or search around the hut? (Knock(1)/Search(2)): ")

    if choice == "1":
        print("\nYou knock on the door, and after a moment, it creaks open.")
        print("The sage peers at you with wise, penetrating eyes. 'What brings you here?' he asks.")
        print("'I have come to find an ancient map leading to a temple high in the mountains,' you reply.")
        print(
            "The sage's eyes widen. 'Come inside, but know this: before you get the map, you must understand what that place truly is.'")
        print(
            "As you step inside, you see that the hut is far larger on the inside, filled with magical artifacts and ancient scrolls.")
        retrieve_map(player)

    elif choice == "2":
        print("\nYou decide to search around the hut quietly, looking for clues.")
        print("After a moment, you hear a voice behind you: 'Lost, are we?' The sage catches you in the act.")
        print("'I see you seek something important. Perhaps the map to the temple?' he says with a sly grin.")
        print(
            "Embarrassed, you explain your quest, and he nods. 'Come inside, and let's discuss what you need to know.'")
        retrieve_map(player)


def retrieve_map(player):
    print("\nAfter hearing your story, the sage agrees to help you, but he requires a favor in return.")
    print("'Bring me a rare herb from the forest, and I will give you the map,' he says.")

    herb_found = input("Do you accept the sage's quest to find the herb? (Yes(1)/No(2)): ")

    if herb_found == "1":
        print(
            "\nYou agree and venture into the dark forest in search of the herb. The air feels thick with magic, "
            "and shadows shift around you.")
        print("The sage described the herb as glowing faintly blue and growing near water.")
        herb_search(player)  # Begin the herb-finding journey

    else:
        print("\nThe sage shakes his head. 'Without the map, you may never find the temple.'")
        print("Determined, you decide to accept his quest after all.")
        retrieve_map(player)


def herb_search(player):
    print("\nAfter some time, you reach a small, misty clearing where a creek flows gently.")
    print("You notice a faint blue glow near the water—it's the herb you're looking for!")

    encounter = random.randint(1, 3)

    if encounter == 1:
        print("\nAs you reach for the herb, a Forest Spirit emerges from the shadows!")
        print("It seems to be guarding the herb and watches you with distrust.")
        choice = input("Do you want to fight the spirit or try to communicate with it? (Fight(1)/Talk(2)): ")

        if choice == "1":
            print("\nYou prepare for a battle!")
            story_monster_encounter(player, Wraith)
            if player.hp <= 0:
                print("After a tough battle, the spirit dissipates, leaving you with the herb.")
                player.gain_xp(75)
            else:
                herb_search(player)
        else:
            print("\nYou speak to the spirit, explaining your need to stop the VoidSpawn.")
            print("The spirit nods, understanding the gravity of the situation, and grants you the herb peacefully.")
            player.gain_xp(75)

    elif encounter == 2:
        print("\nJust as you pluck the herb, a group of bandits appear, attracted by the herb's glow.")
        print("'Hand over that herb, and we won't hurt you!' they threaten.")
        choice = input("Do you want to fight the bandits or try to outsmart them? (Fight(1)/Trick(2)): ")

        if choice == "1":
            print("\nYou stand your ground, ready to defend yourself!")
            story_monster_encounter(player, Bandit)
            if player.hp <= 0:
                print("After a fierce battle, you defeat the bandits and secure the herb.")
                player.gain_xp(75)
            else:
                herb_search(player)
        else:
            print("\nYou convince the bandits that the herb is poisonous and would only curse them.")
            print("They back away cautiously, allowing you to leave unharmed with the herb.")
            player.gain_xp(75)

    else:
        print("\nYou pick the herb without issue, feeling a sense of calm in the forest clearing.")
        player.gain_xp(75)
        print("Fortunate to avoid any dangers, you quickly make your way back to the sage.")

    return_to_sage(player)


def return_to_sage(player):
    print("\nYou return to the sage's hut, presenting him with the rare herb.")
    print("The sage smiles, clearly impressed. 'You have done well,' he says, taking the herb.")
    print("He hands you a worn map, then pauses and looks at you gravely.")
    print(
        "'The temple you seek is more than it appears. It’s called the Cuilë Nandë, the Protector's Sanctuary,"
        "' he explains.")
    print("'There, the VoidSpawn was created to defend our realm, but its power was twisted over time.'")
    print(
        "He places a hand on your shoulder. 'The journey ahead is perilous, but you must be brave. Go, and may you "
        "find victory.'")
    player.gain_xp(150)

    # After receiving the map and advice, the player can now proceed
    journey_to_temple(player)


def journey_to_temple(player):
    print("\nWith the map in hand, you begin your journey to the temple.")
    print("The map leads you through perilous landscapes, hinting at challenges ahead.")
    print("You travel through dense forests, barren hills, and rocky ravines.")

    # Random encounters or obstacles along the way
    encounter_roll = random.randint(1, 4)  # Random encounter chances (1-4)
    if encounter_roll == 1:
        print("\nA group of wild beasts, snarling and hungry, approaches!")
        # Combat logic with wild beasts
        story_monster_encounter(player, "Wild Beasts")

    elif encounter_roll == 2:
        print("\nA sudden storm rolls in, making the journey difficult. You must find shelter!")
        print("\nThe fierce storm starts to pour down, with strong winds and torrential rain.")
        print("You must find shelter or risk exhaustion and injury.")
        choice = input("Do you want to seek shelter (yes/no)? ").lower()
        if choice == "yes":
            print("\nYou manage to find a small cave and wait out the storm.")
            print("You recover some health during the rest.")
            player.hp = min(player.hp + 10, player.max_hp)
            print(f"Your health is now {player.hp}.")
        else:
            print("\nYou decide to brave the storm, but the harsh conditions wear you down.")
            player.hp -= 15
            print(f"Your health is now {player.hp}.")

    elif encounter_roll == 3:
        print("\nYou come across a suspicious traveler. They seem to be watching you.")
        print(
            "\nYou notice a traveler standing by the side of the road. Their eyes glint with an unsettling intensity.")
        choice = input("Do you approach them (yes/no)? ").lower()
        if choice == "yes":
            print(
                "\nThe traveler warns you of dangers ahead but offers little help. They seem to be hiding something...")
            # Option for player to learn something useful or get tricked
            info = random.choice([True, False])
            if info:
                print(
                    "\nThe traveler gives you a cryptic warning: 'Beware the temple’s guardian. Only the worthy shall "
                    "pass.'")
            else:
                print("\nThe traveler disappears into the woods, leaving you unsure whether they were friend or foe.")
        else:
            print("\nYou decide to keep your distance. The traveler watches you leave but says nothing.")
    else:
        print("\nThe journey continues smoothly with no interruptions.")

    print("\nAfter several days of travel, you finally see the temple in the distance...")
    player.gain_xp(75)
    temple_encounter(player)


def temple_encounter(player):
    print("\nAs you approach the temple, an eerie silence envelops the area.")
    print("The structure looms above you, ancient and foreboding.")
    print("You sense that the VoidSpawn is near, its dark presence fills the air.")

    print(
        "\nThe entrance to the temple is massive, with intricate carvings of ancient symbols that glow faintly in the "
        "dim light.")
    print("A massive stone door blocks your way.")

    # Guardian appearance
    print("\nSuddenly, the ground shakes beneath you, and a deep rumbling sound echoes through the air.")
    print("From the shadows of the temple, a massive stone figure emerges.")
    print(
        "The Temple Guardian, a giant stone being, stands before you. It guards the temple and will allow no one "
        "inside without proving their worth.")

    print("\nThe Temple Guardian speaks in a deep, resonant voice:")
    print(
        "'Only those with courage and strength may pass. Defeat me, and the temple’s secrets are yours. Fail, "
        "and you shall remain here, lost forever.'")
    story_boss_encounter(player, "Temple Guardian")
    if player.hp <= 0:
        temple_encounter2(player)
        player.gain_xp(75)
    else:
        temple_encounter(player)


def temple_encounter2(player):
    print("\nWith the Guardian defeated, you stand before the entrance of the ancient temple.")
    print("The heavy stone doors creak open, revealing a dark hallway lined with flickering torches.")
    print("As you step inside, a chill runs down your spine, and an ominous silence fills the air.")

    print("\nYou slowly walk deeper into the temple, your footsteps echoing off the stone walls.")
    print("The dim light reveals faded murals depicting ancient battles and figures holding glowing stones.")
    print("You realize that these murals tell the story of the Soulstone and its power to banish dark forces.")

    # First Room: The Hall of Shadows
    print(
        "\nAfter a few minutes of walking, you enter the Hall of Shadows, an expansive chamber where strange shadows flicker on the walls.")
    print(
        "The air feels thick, as if something is watching you. You notice three doors ahead, each marked with strange symbols.")
    print("One symbol resembles a flame, the other a wave, and the third a mountain.")

    choice = input("Which door do you choose? (flame/wave/mountain): ").strip().lower()

    if choice == "flame":
        print(
            "\nYou enter the Flame Door, and the room immediately heats up. The walls are lined with blazing torches.")
        print("A trap is triggered, and flames shoot across the floor, blocking your path!")
        if player.dodge():
            print("You leap back just in time to avoid the flames, narrowly escaping with no harm.")
        else:
            print("You’re caught in the flames and suffer burns!")
            player.hp -= 10
            print(f"Your health is now {player.hp}.")
        print(
            "You manage to reach the end of the room, finding a clue about the Soulstone’s location etched into the wall.")

    elif choice == "wave":
        print("\nYou enter the Wave Door, and water begins to seep into the room from cracks in the walls.")
        print("The water rises quickly, threatening to flood the room entirely!")
        if player.dodge():
            print(
                "You swim swiftly toward a ladder on the far wall, reaching it just in time to escape the rising water.")
        else:
            print("You struggle in the water, and nearly drown before managing to pull yourself to safety!")
            player.hp -= 10
            print(f"Your health is now {player.hp}.")
        print(
            "You reach the other side of the room and find a small, shimmering token with strange runes. This might be useful later.")
        player.inventory.append("Shimmering Token")

    elif choice == "mountain":
        print("\nYou enter the Mountain Door, and the room begins to rumble.")
        print("Stones fall from the ceiling, making it difficult to proceed without getting hurt.")
        if player.dodge():
            print("You carefully maneuver through the falling stones and avoid injury.")
        else:
            print("A rock hits you as you try to dodge, injuring you.")
            player.hp -= 10
            print(f"Your health is now {player.hp}.")
        print("At the end of the room, you find an ancient map etched into the wall, showing the layout of the temple.")
        print("It reveals that the Soulstone chamber lies deep within, guarded by further traps and puzzles.")
        player.gain_xp(75)

    # Second Room: The Puzzle of Light
    print("\nAfter choosing a door and facing its challenges, you proceed deeper into the temple.")
    print("You enter another chamber filled with mirrors, crystal prisms, and shafts of light streaming in from above.")
    print("An inscription on the wall reads: 'Only by bending light will the path be revealed.'")

    solved = False
    attempts = 0
    while not solved and attempts < 3:
        print(
            "\nYou adjust the mirrors and prisms, trying to direct the light to the far wall where a symbol faintly glows.")
        answer = input("Which direction will you tilt the main prism? (left/right/up/down): ").strip().lower()
        if answer == "left":
            print("\nThe light shifts left and the symbol glows brightly, revealing a hidden doorway!")
            solved = True
        else:
            print("\nThe light misses the symbol, and nothing happens. Try again.")
            attempts += 1

    if not solved:
        print("\nUnable to solve the puzzle, you accidentally trigger a trap!")
        print("Spears shoot out from the walls, and you’re grazed by one.")
        player.hp -= 10
        print(f"Your health is now {player.hp}. You press on, determined to find the Soulstone.")
        player.gain_xp(100)

    # Final Room: The Soulstone Chamber
    print(
        "\nYou pass through the hidden doorway and enter a grand chamber filled with swirling mist and eerie blue light.")
    print("In the center of the room, on a raised stone altar, lies the Soulstone, pulsing with an ethereal glow.")
    print("However, as you approach, a ghostly figure materializes in front of you—a Spirit of the Temple.")

    print(
        "\nThe Spirit speaks: 'Only those who are pure of heart and mind may claim the Soulstone. Prove your worth by answering my question.'")
    question_answered = False
    attempts = 0

    while not question_answered and attempts < 3:
        print("\nThe Spirit asks, 'What is it that all creatures seek, yet few can truly obtain?'")
        answer = input("What is your answer? ").strip().lower()
        if answer in ["peace", "freedom", "happiness", "truth"]:
            print("\nThe Spirit nods solemnly, fading away as it acknowledges your answer.")
            print("The path to the Soulstone is now clear.")
            question_answered = True
            player.gain_xp(100)
        else:
            print("\nThe Spirit frowns. 'That is not the answer. Reflect, and try again.'")
            attempts += 1

    if not question_answered:
        print("\nUnable to answer correctly, you feel a surge of dark energy as the Spirit’s power weakens you.")
        player.hp -= 10
        print(f"Your health is now {player.hp}. However, you still approach the Soulstone.")

    # Final steps: Claiming the Soulstone
    print("\nYou step up to the altar and reach out to claim the Soulstone.")
    print(
        "As your fingers brush its surface, a surge of energy flows through you. The stone feels alive, pulsating "
        "with ancient magic.")

    print(
        "\nWith the Soulstone in hand, you feel a deep connection to it. Visions flash in your mind of the battles "
        "fought to protect it.")
    print("This powerful artifact can seal away the Voidspawn once more, but only if wielded wisely.")

    # Rewards and Final Message
    player.inventory.append("Soulstone")
    player.gain_xp(500)
    print("\nYou gained the Soulstone! You feel stronger and more resolved to complete your quest.")
    print(f"Your inventory now includes the Soulstone, and you gained 500 XP!")

    print(
        "\nWith the Soulstone in hand, you exit the temple, knowing that the fate of the land now rests in your hands.")
    print(
        "The journey ahead is treacherous, but with the Soulstone, you may just have a chance to vanquish the "
        "Voidspawn once and for all.")


def kingdom_journey(player):
    print("\nYou decide to journey to the kingdom of Salvia, entrusting Calvin with the task of going to the temple.")
    print(
        "The path to Salvia is long and fraught with danger, but it is your best chance to rally support and gather resources.")
    print("With determination in your heart, you set out on the road, the sun rising behind you.")

    # The First Encounter: Bandit Ambush
    print(
        "\nAfter several hours of travel, you reach a dense forest. The sound of birdsong is suddenly replaced by rustling bushes.")
    print("A group of ragged bandits steps onto the path, weapons drawn, their leader smirking arrogantly.")
    print("Bandit Leader: 'Hand over your valuables, traveler, and we might let you pass unharmed!'")

    decision = input("Do you (fight), (negotiate), or (flee)? ").strip().lower()

    if decision == "fight":
        print("\nYou draw your weapon, ready to defend yourself.")
        story_monster_encounter(player, bandit)
        story_monster_encounter(player, bandit)
        story_monster_encounter(player, bandit)
        if player.hp > 0:
            print("With skill and precision, you fend off the bandits, leaving them defeated on the forest floor.")
            print("As the leader flees, you find a small pouch of coins on one of the fallen bandits.")
            player.inventory.append("Pouch of Coins")
            player.gold += 20
            print("You gain 20 gold.")
        else:
            print("You fight valiantly but the bandits got the best of you")
            kingdom_journey(player)

    elif decision == "negotiate":
        print("\nYou raise your hands in a gesture of peace and try to reason with the bandits.")
        chance = random.randint(1,20)
        if chance >= 12:
            print(
                "Your words strike a chord with the bandit leader. He allows you to pass unharmed, even offering you a tip about the road ahead.")
            print("'Beware the old bridge,' he warns before disappearing into the forest.")
        else:
            print("The bandits scoff at your attempts to negotiate and attack!")
            player.hp -= 10
            print(f"You lose 10 HP but manage to escape with minor injuries. Your health is now {player.hp}.")

    elif decision == "flee":
        print("\nYou turn and sprint back the way you came, dodging arrows and shouts.")
        print("The bandits give chase but eventually lose interest as you disappear into the woods.")
        print("Although you avoided a fight, you’ve lost precious time.")

    # The Old Bridge
    print("\nContinuing your journey, you come across a rickety old bridge spanning a deep chasm.")
    print("The wood looks weathered and weak, and the ropes creak ominously in the wind.")
    print("A sign nearby reads: 'Bridge unstable. Cross at your own risk.'")

    decision = input("Do you (cross), (find another way), or (inspect the bridge)? ").strip().lower()

    if decision == "cross":
        print("\nYou step cautiously onto the bridge, testing each plank before proceeding.")
        chance = random.randint(1, 20)
        if chance >= 8:
            print("You make it across safely, the bridge swaying dangerously but holding steady under your weight.")
        else:
            print(
                "Halfway across, a plank snaps beneath you! You manage to grab onto a rope and pull yourself to safety.")
            player.hp -= 10
            print(f"You lose 10 HP in the process. Your health is now {player.hp}.")

    elif decision == "find another way":
        print("\nYou decide the bridge is too risky and begin searching for another route.")
        print(
            "After hours of hiking through dense underbrush, you find a shallow part of the chasm and carefully climb down and back up.")
        print("The detour costs you valuable time, but you avoid any immediate danger.")

    elif decision == "inspect the bridge":
        print("\nYou examine the bridge closely and discover a series of ropes that can be reinforced.")
        if "Rope" in player.inventory:
            print("Using the rope in your inventory, you stabilize the bridge and cross safely.")
        else:
            print("Without proper tools, you are unable to reinforce the bridge and must cross as is.")
            chance = random.randint(1, 20)
            if chance >= 8:
                print("Fortunately, you make it across without incident.")
            else:
                print("The bridge collapses under your weight, and you barely manage to climb to safety.")
                player.hp -= 10
                print(f"You lose 10 HP in the process. Your health is now {player.hp}.")

    # Arrival at Salvia
    print("\nAfter days of travel, you finally see the gates of Salvia on the horizon.")
    player.gain_xp(150)
    print("The grand walls of the kingdom rise high, their stone glinting in the sunlight.")
    print("As you approach, a guard stops you. 'State your name and purpose.'")

    print("\nYou explain your mission, describing the threat of the Voidspawn and the need for allies.")
    chance = random.randint(1, 20)
    if chance >= 10:
        print("The guard listens intently and nods, impressed by your resolve.")
        print("'We will inform the council of your arrival. You may enter.'")
        player.gain_xp(200)
        print("You gain 200 XP.")
    else:
        print("The guard seems skeptical and orders you to wait while he confirms your story.")
        print("After a tense hour, you are finally allowed to enter the kingdom, albeit under watchful eyes.")

    print(
        "\nInside Salvia, the streets buzz with activity. Merchants peddle their wares, townsfolk chatter, \n"
        "and soldiers march in formation.")
    print("You now stand at the heart of the kingdom, ready to plead your case to the council and secure their aid.")
    print("The journey has been grueling, but your resolve is stronger than ever.")
    salvia(player)


def salvia(player):
    print("You make your way to the capital city of Salvia, the heart of the kingdom.")
    print("The journey is long, spanning several days through varied terrain.")

    # Travel sequence
    print("\nAs you travel, the weather shifts from a gentle breeze to an ominous storm.")
    print("The road is muddy, and progress is slow. You spot an inn ahead, offering shelter for the night.")
    print("\nDo you:")
    print("1. Stay at the inn and rest.")
    print("2. Continue traveling through the storm.")
    choice = input("Choose your action (1/2): ")

    if choice == "1":
        print("\nYou enter the inn, welcomed by the warmth of a crackling fire and the smell of stew.")
        print("You pay 5 gold for a room and sleep soundly, regaining your strength.")
        self.hp = min(self.hp + 20, self.max_hp)
        player.gold -= 5
        print(f"Your HP is now {player.hp}, and you have {player.gold} gold left.")
    elif choice == "2":
        print("\nYou press on through the storm, but the journey takes a toll on you.")
        print("The wind howls, and rain lashes against your body.")
        player.hp -= 15  # Take damage for braving the storm
        print(f"You lose 15 HP. Your current HP is {player.hp}.")
        print("Eventually, the storm subsides, and you continue your journey, though weary.")

    # Encounter with bandits
    print("\nAs the sun rises, you hear rustling in the bushes nearby.")
    print("Before you can react, a group of bandits emerges, blocking your path.")
    print("The leader, a burly man with a scar across his face, steps forward.")
    print("'Hand over your gold and supplies, and we’ll let you pass,' he growls.")

    print("\nDo you:")
    print("1. Attempt to negotiate with the bandits.")
    print("2. Fight the bandits.")
    print("3. Try to flee.")
    choice = input("Choose your action (1/2/3): ")

    if choice == "1":
        print("\nYou attempt to reason with the bandits, explaining your mission.")
        if player.character_class == "Rogue":
            print("Using your cunning, you convince them to let you go, offering a small sum of gold.")
            player.gold -= 10
            print("You lose 10 gold but avoid a fight. The bandits begrudgingly step aside.")
        else:
            print("The bandits laugh at your words and demand more gold.")
            player.gold -= 20
            print("You lose 20 gold and proceed with gritted teeth.")
    elif choice == "2":
        print("\nYou draw your weapon, prepared to defend yourself.")
        print("The battle is intense, but your skills prevail.")
        story_monster_encounter(player, "Bandit")
        story_monster_encounter(player, "Bandit")
        print(f"You defeat the bandits. Your HP is now {player.hp}.")
        print("You loot their belongings and find 30 gold.")
        player.gold += 30
    elif choice == "3":
        print("\nYou sprint into the forest, dodging branches and leaping over roots.")
        print("The bandits chase you for a while but eventually give up.")
        print("You escape unharmed but lose valuable time on your journey.")

    # Arrival in Salvia
    print("\nAfter several more days of travel, you finally reach the gates of Salvia.")
    print("The city is alive with activity, a stark contrast to the wilds you’ve just traversed.")
    print("Merchants shout their wares from colorful stalls lining the cobblestone streets.")
    print("- 'Fresh bread and pastries!'")
    print("- 'Spices from the farthest reaches of the kingdom!'")
    print("- 'Rare gems and trinkets for the discerning buyer!'")

    print("\nDespite the allure of the market, you remember your purpose and make your way to the palace.")

    # Interactions in the city
    print("\nAlong the way, you notice a commotion in the market square.")
    print("A child has been caught stealing, and the merchant is demanding retribution.")
    print("\nDo you:")
    print("1. Intervene on the child’s behalf.")
    print("2. Side with the merchant.")
    print("3. Ignore the situation and continue to the palace.")
    choice = input("Choose your action (1/2/3): ")

    if choice == "1":
        print("\nYou step forward and offer to pay for the stolen goods.")
        print("The merchant grudgingly accepts, and the child thanks you tearfully.")
        player.gold -= 10
        print(f"You lose 10 gold. Your current gold is {player.gold}.")
    elif choice == "2":
        print("\nYou support the merchant, explaining the importance of law and order.")
        print("The crowd murmurs in agreement, and the child is led away, crying.")
    elif choice == "3":
        print("\nYou turn away from the scene, focusing on your mission.")
        print("The cries of the child fade as you make your way to the palace.")

    # Palace encounter
    print("\nThe palace gates loom ahead, guarded by two stern-looking soldiers.")
    print("You state your business, and after some convincing, you are allowed entry.")
    print("Inside, the grandeur of the palace takes your breath away.")
    print("Velvet carpets line the floors, and chandeliers of pure crystal hang from the ceiling.")
    print("\nYou are led into the throne room, where King Alden and his council await.")
    print("The king listens intently as you explain the threat of the VoidSpawn.")

    print("\nDo you:")
    print("1. Use charisma to appeal to their sense of duty.")
    print("2. Present evidence of the VoidSpawn’s destruction.")
    print("3. Emphasize the urgency and threaten consequences if they do nothing.")
    choice = input("Choose your approach (1/2/3): ")

    if choice == "1":
        print("\nYou speak with passion and eloquence, stirring a sense of duty in the council.")
        print("The king nods solemnly. 'Your words carry great weight. We will aid you.'")
    elif choice == "2":
        print("\nYou present artifacts and accounts from your journey, proving the threat is real.")
        print("The council exchanges worried glances before agreeing to support you.")
    elif choice == "3":
        print("\nYour stern words and dire warnings unsettle the council.")
        print("Though reluctant, they agree to aid you, unwilling to risk ignoring the threat.")

    # Rewards
    print("\nThe king grants you supplies, gold, and a detachment of soldiers to aid in your quest.")
    player.inventory.append("allies")
    player.gain_xp(200)
    reward_gold = 100
    player.gold += reward_gold
    print(f"You receive {reward_gold} gold and provisions for your journey.")
    print(f"Your total gold is now {player.gold}.")

    print("\nWith the kingdom's support secured, you prepare to set out on the next leg of your journey.")
    main_story3(player)

def main_story3(player):
    print("\n--- Chapter 3: The Pieces of the Soulstone ---")
    print("--------------------Part 1---------------------")
    print("When you return to Glimmerreach you see Calvin there waiting for you.")
    print("'Hey, I've got the soulstone' Calvin says")
    print("'Wait' you say. 'This looks broken'")
    print("Calvin looks at the stone. Startled he says 'You're right. Let me take this to a guy I know.\nHe might "
          "be able to tell us where the other shards are.'")
    # The player and Calvin visit a shop
    print("\nYou and Calvin head to a small shop in the heart of Glimmerreach.")
    print("An old scholar greets you, his robes tattered but his eyes sharp with wisdom.")
    print("'This Soulstone is ancient,' he says, examining it carefully.")
    print(
        "'It was shattered into three shards, scattered across the land long ago. Each shard is protected "
        "by great peril.'")
    print("'To seal away the Voidspawn, you must recover each piece,' the scholar warns.")
    print("He rolls out a dusty map and points to three marked locations.")
    print("The first shard lies in the Forest of Eternal Twilight,")
    print("the second in the Forgotten Desert City, and the final one in the Abyss of Nightmares.")

    # Proceed to the shard quests
    print("\nYou tell Calvin to stay here and protect the village while you go recover the shards.")
    print("'I'll head to the Forest first.'")
    print("With a determined nod, you set out on your quest.")
    print("The Soulstone was shattered into three shards, scattered across the land.")
    print("To seal away the Voidspawn, you must recover each piece, but each comes with its own peril.")
    print("The first shard is in the Forest of Eternal Twilight.")
    first_shard_journey(player)

    print("\nWith all three shards in hand, the time has come to reforge the Soulstone.")
    print("You sense the Voidspawn's power growing stronger with each passing moment...")
    player.gain_xp(200)
    # You can proceed to the next chapter here or allow the player to make decisions about the Soulstone.

def first_shard_journey(player):
    print("\n--- Journey to the Forest of Eternal Twilight ---")
    print("You leave Glimmerreach at dawn, the golden light of the sun warming your back as you set out.")
    print("The path winds through rolling hills and dense woodlands. You pass a traveling merchant who offers wares.")
    merchant_choice = input("Do you stop to browse the merchant’s goods (1) or continue on your way (2)? ")

    if merchant_choice == "1":
        print("\nThe merchant shows you a collection of potions and enchanted trinkets.")
        print("You purchase a healing potion, spending 20 gold.")
        player.gold -= 20
        player.inventory.append("Healing Potion")
    else:
        print("\nYou nod at the merchant and continue down the path, eager to reach your destination.")

    print("\nAs you near the Forest of Eternal Twilight, the environment grows eerily quiet.")
    print("The air is thick, and strange shadows seem to move among the trees.")
    print("The legend of this forest whispers in your mind, a place where time and reality blur.")
    print("Taking a deep breath, you step into the forest, prepared for the trials ahead.")
    first_shard(player)

def first_shard(player):
    print("\n--- The First Shard: The Forest of Eternal Twilight ---")
    print("You journey to the Forest of Eternal Twilight, where the sun never sets and shadows stretch endlessly.")
    print("Legends speak of time behaving strangely here, twisting the past, present, and future into one.")
    print("As you step into the forest, the air grows heavy, and the distant sound of laughter chills your bones.")

    # Encounter with twisted versions of yourself
    print("\nAs you tread deeper into the woods, figures step from the shadows—twisted versions of yourself.")
    print("These manifestations wear cruel smiles, mocking you with glimpses of alternate lives.")
    decision = input("Do you confront the twisted versions (1) or try to sneak past them (2)? ")

    if decision == "1":
        print("\nYou steel yourself and confront the twisted versions. They lash out with words and claws alike!")
        story_boss_encounter(player, "Children of the void")
        if player.hp <= 0:
            print("The forest's curse overpowers you, but your will pulls you back. You awaken at the forest's edge.")
            first_shard(player)  # Restart the shard quest
    else:
        print("\nYou try to sneak past, but their mocking laughter follows you, echoing in your mind.")

    # Puzzle at the grove
    print("\nEventually, you arrive at a grove bathed in a pale silver light.")
    print("At its center, the shard floats above an altar, protected by whispering forest spirits.")
    print("The spirits speak: 'Prove your worth with wisdom. Answer this riddle to claim the shard.'")
    puzzle_answer = input("Riddle: What has roots as nobody sees, is taller than trees? (Hint: Think Tolkien) ")

    if puzzle_answer.lower() == "mountain":
        print("\nThe spirits hum with approval, and the shard lowers into your hands.")
        pact(player)
    else:
        print("\nThe spirits hiss in displeasure. Shadows rise to attack, but you seize the shard amidst the chaos.")
        print("However, the forest's curse lingers, reducing your maximum HP by 10.")
        player.hp -= 10
    print("You now hold the first shard of the Soulstone.")
    player.inventory.append("soulstone shard")
    player.gain_xp(150)
    second_shard_journey(player)

def pact(player):
    print("The spirits offer you to make a pact with them.")
    pact_choice = input("\nDo you form a pact with the spirits for their blessing (1) or leave with the shard (2)? ")

    if pact_choice == "1":
        print("\nThe spirits bind their essence to yours, enhancing your magic and insight.")
        player.magic_power += 5
    else:
        print("\nYou take the shard and leave, the whispers of the spirits fading as you exit the grove.")

def second_shard_journey(player):
    print("\n--- Journey to the Forgotten Desert City ---")
    print("With the first shard in hand, you prepare for the next leg of your journey.")
    print("The path to the Forgotten Desert City takes you across the Gilded Plains, a land of golden grasslands.")
    print("You encounter a caravan of traders camped by an oasis.")
    caravan_choice = input("Do you rest with the caravan and trade stories (1) or press on through the night (2)? ")

    if caravan_choice == "1":
        print("\nThe traders welcome you to their fire, offering food and conversation.")
        print("You share tales of your quest, earning a blessing from a wandering cleric.")
        player.hp = min(player.hp + 10, player.max_hp)
    else:
        print("\nYou choose to press on, but the night’s journey saps your strength.")
        player.hp -= 10

    print("\nThe golden plains give way to barren deserts. The sun blazes overhead, and each step grows heavier.")
    print("You finally glimpse the towering ruins of the Forgotten Desert City, half-buried in the shifting sands.")
    print("The city looms like a phantom from another age, its crumbled walls whispering forgotten secrets.")
    second_shard(player)

def second_shard(player):
    print("\n--- The Second Shard: The Forgotten Desert City ---")
    print("The city’s ruins are a sprawling maze of broken buildings and shifting sands, imbued with ancient magic.")
    print("To retrieve the shard, you must prove yourself in the Trials of Virtue.")

    # **Trial 1: Test of Compassion**
    print("\n--- Trial 1: Test of Compassion ---")
    print("As you wander through the ruins, you hear desperate cries for help.")
    print("A villager is trapped under a collapsed pillar. Nearby, a chest of treasure glimmers in the sunlight.")
    trial_choice_1 = input("Do you rescue the villager (1) or claim the treasure (2)? ")

    if trial_choice_1 == "1":
        print("\nYou push the rubble aside and free the villager, but in doing so, you lose valuable time and "
              "resources.")
        player.gold -= 20
        player.xp += 50
    else:
        print("\nYou ignore the cries and seize the treasure, gaining wealth but feeling the weight of your choice.")
        player.gold += 50

    # **Trial 2: Test of Wisdom**
    print("\n--- Trial 2: Test of Wisdom ---")
    print("You come across a towering door covered in ancient runes, pulsating faintly with energy.")
    print("A disembodied voice echoes: 'Only those who understand the balance of the world may pass.'")
    puzzle_answer = input("Riddle: What walks on four legs in the morning, two at noon, and three in the evening? ")

    if puzzle_answer.lower() in ["man", "human"]:
        print("\nThe runes glow brightly and the door creaks open. Your wisdom has been acknowledged.")
        player.xp += 30
    else:
        print("\nThe runes flare angrily, and the door remains shut. You are forced to find another way.")
        print("Navigating around the barrier takes time, leaving you drained.")
        player.hp -= 10

    # **Trial 3: Test of Resolve**
    print("\n--- Trial 3: Test of Resolve ---")
    print("The path leads you to a dark chamber filled with shifting shadows.")
    print("A spectral creature emerges, whispering your deepest fears and doubts.")
    trial_choice_3 = input("Do you confront the specter head-on (1) or attempt to banish it with magic (2)? ")

    if trial_choice_3 == "1":
        print("\nYou charge at the specter, braving its illusions. Your resolve strengthens as you overcome your fear.")
        player.xp += 40
    else:
        if player.character_class in "Wizard":
            print("\nYou focus your magic to banish the specter, but the effort takes a toll on your energy.")
            player.hp -= 5
        else:
            print("Fighters and Rogues cannot do magic.")

    # **Encounter with the Fatebound Guardian**
    print("\n--- The Guardian's Judgment ---")
    print("At the heart of the ruins, a colossal Fatebound Guardian spirit awaits you.")
    if trial_choice_1 == "1" and puzzle_answer.lower() in ["man", "human"] and trial_choice_3 == "1":
        print("The guardian nods solemnly, impressed by your compassion, wisdom, and resolve.")
        print("It grants you the shard without conflict, acknowledging your worth.")
    else:
        print("The guardian deems your trials incomplete and attacks to test your strength.")
        story_boss_encounter(player, "Temple Guardian")
        if player.hp <= 0:
            print("\nThe guardian defeats you. You must try again.")
            second_shard(player)

    print("\nYou now hold the second shard of the Soulstone.")
    player.inventory.append("soulstone shard 2")
    player.gain_xp(150)
    final_shard_journey(player)

def final_shard_journey(player):
    print("\n--- Journey to the Abyss of Nightmares ---")
    print("The final shard lies in the Abyss of Nightmares, a rift between realms where reality bends and breaks.")
    print("You prepare yourself mentally and physically for the most harrowing part of your journey.")
    print("The path leads through the Ashen Wastes, a desolate landscape scarred by ancient battles.")
    print("As you cross the wastes, you face a choice: brave the perilous canyon of shadows or the treacherous ridge of winds.")
    path_choice = input("Do you take the canyon of shadows (1) or the ridge of winds (2)? ")

    if path_choice == "1":
        print("\nThe canyon of shadows is dark and foreboding, whispers echoing off its jagged walls.")
        print("You feel eyes watching you, and a shadowy figure attacks!")
        story_monster_encounter(player, "Shadow")
        if player.hp <= 0:
            print("\nThe wraith overpowers you, leaving you on the brink of death. You retreat to recover.")
            final_shard_journey(player)
    else:
        print("\nThe ridge of winds howls with violent gusts, threatening to throw you into the abyss below.")
        print("You use your skill and determination to cross safely, though the journey leaves you exhausted.")
        player.hp -= 10

    print("\nAt the end of the Ashen Wastes, you find the rift to the Abyss of Nightmares.")
    print("The air crackles with otherworldly energy, and your resolve hardens as you step into the unknown.")
    final_shard(player)

def final_shard(player):
    print("\n--- The Final Shard: The Abyss of Nightmares ---")
    print("Your journey takes you to a tear in reality, a rift leading to the Abyss of Nightmares.")
    print("Here, the Voidspawn's influence is strongest, twisting reality into a maze of fears and illusions.")

    # Navigating the rift
    print("\nThe air crackles with energy as the rift pulls you into a world of surreal horrors.")
    navigation = input("Do you trust your instincts to navigate (1) or analyze the shifting surroundings (2)? ")

    if navigation == "1":
        print("\nYour instincts guide you, but the Abyss drains your strength with each step.")
        player.hp -= 10
    else:
        print("\nYour careful observations help you navigate safely, avoiding unnecessary harm.")

    # Confronting fears
    print("\nThe Voidspawn manifests visions of your deepest fears, trying to break your spirit.")
    fear_choice = input("Do you confront the fears head-on (1) or retreat to avoid their influence (2)? ")

    if fear_choice == "1":
        print("\nYou try to attack the Voidspawn but he just laughs in your face.")
        print("The laughter is haunting and with the command of the Voidspawn, Enemy's appear")
        story_monster_encounter(player, "Children of the void")
        story_monster_encounter(player, "Children of the void")
        story_monster_encounter(player, "Children of the void")
        if player.hp > 0:
            player.gain_xp(250)
        else:
            print("The Children Overpower you. Better luck next time.")
            final_shard(player)
    else:
        print("\nYou avoid the visions, but the sense of fear lingers in your heart, shaking your confidence.")
        print("But one of the Voidspawn's minions attack")
        story_monster_encounter(player, "Children of the void")
        if player.hp > 0:
            player.xp += 300
        else:
            print("The Child Overpowers you. Better luck next time.")
            final_shard(player)

    # Final choice: The Voidspawn's deal
    print("\nThe Voidspawn appears, a looming shadow offering you a choice.")
    final_choice = input("Do you take the shard and risk corruption (1) or make a deal with an ancient entity (2)? ")

    if final_choice == "1":
        print("\nYou seize the shard, but the Voidspawn’s influence leaves a mark on your soul.")
        player.hp -= 30  # Represents lingering corruption
    else:
        print("\nYou make a deal with the ancient entity, gaining the shard and a dark power.\n but you wonder if you"
              " did the right thing")
        player.magic_power += 15
        player.inventory.append("dark power")

    print("You now hold the final shard of the Soulstone.")
    player.gain_xp(500)
    player.inventory.append("soulstone shard 3")

def main_story4(player):
    print("\n--- Chapter 4: The Gathering Storm ---")
    print("----------------Part 1-----------------")
    print("The Soulstone shards are now in your possession, but the world is not as it was.")
    print("The Voidspawn’s influence spreads faster than you expected, warping the lands and corrupting its creatures.")
    print(
        "To reforge the Soulstone, you must first return to Glimmerreach, uncover the reforging ritual, and journey to "
        "the Lost City of Souls.")
    print("Every step is fraught with danger and moral choices. The fate of Fatebound depends on you.")
    leave_abyss(player)  # Stage 1
    player.gain_xp(500)
    journey_home(player)  # Stage 2
    player.gain_xp(500)
    chap4p2(player)  # Uncover the ritual in Glimmerreach
    player.gain_xp(500)
    journey_to_mountain(player)  # Stage 3
    player.gain_xp(500)
    reforge_soulstone(player)  # Final Stage
    player.gain_xp(750)


def leave_abyss(player):
    print("\n--- Leaving the Abyss of Nightmares ---")
    print("The Abyss resists your escape. The air is thick with despair, and illusions twist the path ahead.")
    print("You must navigate three key challenges to escape: the Maze of Shadows, the Rift Lake, and the Abyss Gate.")
    maze_of_shadows(player)  # Part 1
    rift_lake(player)  # Part 2
    abyss_gate(player)  # Part 3

def maze_of_shadows(player):
    print("\nYou find yourself in the Maze of Shadows, where every path seems to lead nowhere.")
    print("Whispering voices tempt you to abandon hope, but you press on.")
    choice = input("Do you follow the whispers (1) or use your intuition to navigate (2)? ")

    if choice == "1":
        print("\nThe whispers lead you to a dead end where shadow creatures attack!")
        story_boss_encounter(player, "Shadow")
    elif choice == "2":
        print("\nYou close your mind to the whispers and focus. Eventually, you find the way out.")
    else:
        print("\nInvalid choice. The Maze confounds you. Try again.")
        maze_of_shadows(player)

def rift_lake(player):
    print("\nYou reach a massive lake filled with glowing rifts of energy.")
    print("The lake hums with power, but crossing it is the only way forward.")
    choice = input("Do you use a raft you find nearby (1) or attempt to swim across (2)? ")

    if choice == "1":
        print("\nThe raft seems safe, but halfway across, a Rift Serpent emerges from the depths!")
        story_boss_encounter(player, "Giant Worm")
    elif choice == "2":
        print("\nSwimming is treacherous. The lake’s energy saps your strength, and shadow fish attack!")
        player.hp -= 15
        print(f"Your health is now {player.hp}. You barely make it across.")
    else:
        print("\nInvalid choice. The lake grows more unstable. Try again.")
        rift_lake(player)

def abyss_gate(player):
    print("\nYou finally reach the Abyss Gate, a massive portal guarded by an Abyss Warden.")
    print("The Warden demands a toll to pass: a memory or a part of your soul.")
    choice = input("Do you offer a memory (1) or fight the Warden (2)? ")

    if choice == "1":
        print("\nYou sacrifice a cherished memory, feeling a piece of yourself fade away.")
        player.intelligence -= 1
        print(f"Your intelligence is now {player.intelligence}.")
    elif choice == "2":
        print("\nThe Warden attacks with relentless fury!")
        story_boss_encounter(player, "Abyss Warden")
    else:
        print("\nInvalid choice. The Warden grows impatient. Try again.")
        abyss_gate(player)


def journey_home(player):
    print("\n--- Journey Back to Glimmerreach ---")
    print("The Voidspawn’s corruption spreads across the land, twisting nature and turning creatures hostile.")
    print(
        "You must traverse three dangerous regions to return home: the Blighted Forest, the Ashen Fields, and the "
        "Gates\nof Glimmerreach.")

    blighted_forest(player)  # Part 1
    ashen_fields(player)  # Part 2
    gates_of_glimmerreach(player)  # Part 3

def blighted_forest(player):
    print("\nThe once-beautiful forest is now a rotting husk of its former self.")
    print("You hear eerie howls and the rustling of unseen creatures.")
    choice = input("Do you stick to the path (1) or cut through the underbrush (2)? ")

    if choice == "1":
        print("\nThe path is ambushed by corrupted wolves!")
        story_monster_encounter(player, "Wild Beasts")
    elif choice == "2":
        print("\nThe underbrush slows you down, but you avoid most enemies.")
        player.hp -= 5
        print(f"Your health is now {player.hp}.")
    else:
        print("\nInvalid choice. The forest grows more dangerous. Try again.")
        blighted_forest(player)

def ashen_fields(player):
    print("\nThe Ashen Fields are a barren wasteland where the ground smolders and the air is thick with ash.")
    print("You see a patrol of Voidspawn minions ahead.")
    choice = input("Do you engage the patrol (1) or try to sneak past (2)? ")

    if choice == "1":
        print("\nThe patrol attacks!")
        story_monster_encounter(player, "Voidspawn Minion")
        story_monster_encounter(player, "Voidspawn Minion")
        story_monster_encounter(player, "Voidspawn Minion")
        story_monster_encounter(player, "Voidspawn Minion")
        story_monster_encounter(player, "Voidspawn Minion")
    elif choice == "2":
        print("\nYou successfully sneak past, but the ash burns your lungs.")
        player.hp -= 10
        print(f"Your health is now {player.hp}.")
    else:
        print("\nInvalid choice. The patrol spots you. Try again.")
        ashen_fields(player)

def gates_of_glimmerreach(player):
    print("\nYou finally see the gates of Glimmerreach, but they are under siege by Voidspawn forces.")
    print("The defenders are barely holding on. You must help them break the siege.")
    story_boss_encounter(player, "Children of the void")
    story_boss_encounter(player, "Children of the void")
    story_boss_encounter(player, "Children of the void")
    story_boss_encounter(player, "Children of the void")
    if player.hp >= 0:
        print("\nWith the siege broken, you enter the city to prepare for the next phase of your quest.")
    else:
        gates_of_glimmerreach(player)


def chap4p2(player):
    print("\n--- Chapter 4: The Gathering Storm ---")
    print("----------------Part 2-----------------")
    print("The once-safe city of Glimmerreach now trembles under the shadow of the Voidspawn's growing power.")
    print("You must uncover the ancient ritual needed to reforge the Soulstone by seeking out the Archmage Andelari.")
    print("The streets are chaotic, with citizens divided between fear and rebellion.")

    print("\nYour first task is to reach Andelari's tower, which lies at the heart of the city.")
    choice = input("Do you take the main streets, risking an ambush (1), or use the abandoned sewer tunnels (2)? ")

    if choice == "1":
        print("\nThe main streets are crawling with Voidspawn agents and rebellious mobs.")
        print("You face multiple skirmishes, but the quickest route leads you to the tower.")
        player.hp -= 10
        print(f"Your health is now {player.hp}.")
    elif choice == "2":
        print("\nThe sewers are dark, damp, and eerily silent. You feel eyes watching you from the shadows.")
        story_monster_encounter(player, "Goblin")
        story_monster_encounter(player, "Goblin")
        story_monster_encounter(player, "Goblin")
        if player.hp >= 0:
            print("After defeating the lurking creature, you emerge near Andelari's tower.")
        else:
            print("The Goblins take defeat you. Try again")
            chap4part2(player)
    else:
        print("\nInvalid choice. The city grows more perilous. Try again.")
        chap4p2(player)

    print("\nYou reach the tower and find Archmage Andelari in her study.")
    print("\n--- Inside Andelari's Tower ---")
    print("The tower is a refuge from the chaos outside. Its walls shimmer with protective wards, and shelves overflow "
          "with ancient tomes.")
    print("Andelari, a figure of calm amidst the storm, greets you with a solemn expression.")

    print("\n'Time is short,' she says, gesturing to an old map sprawled across her desk. 'The Soulstone can be "
          "reforged, but it will not be easy.'")
    print("She explains the ritual requires three rare components: Essence of Light, a Shard of Pure Shadow, and the "
          "Tears of the Ancients.")

    print("\n'These artifacts are scattered across the land, each hidden in places tied to ancient powers.'")
    print("\n1. **The Essence of Light**: 'Hidden within the radiant halls of the Sunspire Monastery. However, the "
          "Voidspawn's corruption may have reached even there. Be prepared.'")
    print("\n2. **The Shard of Pure Shadow**: 'It lies in the Abyss of Nightmares, a realm where fear takes form.\n"
          "The journey alone may break even the strongest of wills.'")
    print("\n3. **The Tears of the Ancients**: 'This is the most elusive of all, for it is held in the Lost City of \n"
          "Souls, high within the Final Peak.'")

    print("\nYou interrupt: 'The Lost City of Souls? I've heard whispers, but no one truly knows its location.'")
    print("\nAndelari nods gravely. 'The Lost City is a place where the living and dead converge. Its gates are \n"
          "hidden, and only one who understands the nature of the soul can find it.'")
    print("'Legends say the city was built by an ancient civilization devoted to protecting the balance of life and \n"
          "death. The Tears are kept in the Kingsguard, the city's fortress, but the way there is perilous.'")

    print("\nShe hands you a faded journal. 'This belonged to an adventurer who once sought the city. It contains \n"
          "fragments of their journey.'")
    print("The journal details a treacherous path: first through the Howling Gorge, then the Icebound Caverns, \n"
          "and finally to the Final Peak, where the city's gates are hidden.")

    print("\nAndelari’s tone grows stern. 'Each of these components tests a different part of your soul—your resolve, "
          "\nyour morality, and your strength.'")
    print("'Bring the components here, and only then can the Soulstone be reforged. But beware, for the Voidspawn \n"
          "will sense your actions and grow more desperate.'")

    print("\nWith her final warning ringing in your ears, you prepare for the daunting journey ahead.")

    print("\nBefore you leave, Andelari warns you: 'Each component tests a different part of your soul—your resolve, "
          "your morality, and your strength.'")
    essenceoflight(player)
    shardofpureshadow(player)



def essenceoflight(player):
    print("\n--- Quest: The Essence of Light ---")
    print("Your journey begins at the Sunspire Monastery, a once-holy sanctuary high atop the cliffs of Solara Ridge.")
    print(
        "The air grows warmer as you approach, the golden spires glimmering in the sunlight. Yet something feels off.")
    print(
        "Corruption has tainted this sacred place. The once-bright grounds are shadowed, and the sound of eerie \n"
        "whispers fills the air.")

    print("\nAt the gates, you encounter a group of monks. They seem wary, their faces pale and their eyes hollow.")
    choice = input("Do you try to reason with them peacefully (1) or prepare for combat (2)? ")

    if choice == "1":
        print("\nYou approach the monks with your hands raised, speaking calmly.")
        print("They reveal that the Voidspawn's corruption has spread, infecting many of their brethren.")
        print("They offer to help you navigate the monastery but warn that some areas may be beyond saving.")
    elif choice == "2":
        print("\nThe monks, fearing for their lives, attack!")
        story_boss_encounter(player, "Corrupted Monk")
        print("Defeating them, you press onward, though the confrontation weighs heavily on your conscience.")
    else:
        print("\nInvalid choice. The corruption grows stronger. Try again.")
        essenceoflight(player)

    print(
        "\nInside the Sunspire Monastery, the path to the Essence of Light is guarded by radiant constructs, \n"
        "now corrupted.")
    print("\n--- Trial 1: The Room of Blinding Light ---")
    print(
        "You step into a chamber where the walls emit an intense, radiant light. The brilliance is so overwhelming \n"
        "that it blinds your vision.")
    print("A soft voice echoes through the room: 'Only those who move with calm and faith shall find the way.'")

    choice = input(
        "Do you:\n1. Rush forward, hoping to find the exit quickly.\n2. Close your eyes and walk cautiously, \n"
        "trusting your instincts.\n")

    if choice == "1":
        print(
            "\nThe light intensifies, disorienting you further. You stumble into an unseen obstacle, the pain \n"
            "forcing you to retreat.")
        print("Realizing haste won’t work, you try again.")
        return essenceoflight(player)  # Restart trial
    elif choice == "2":
        print("\nYou close your eyes, letting go of fear. Step by step, you move forward with a calm mind.")
        print("Eventually, the light fades, and you find yourself at the chamber’s exit.")
    else:
        print("\nInvalid choice. The light seems to mock your indecision. Try again.")
        return essenceoflight(player)

    print("\n--- Trial 2: The Riddle of the Wall ---")
    print("The next room is silent, with walls covered in glowing runes. At the center, an inscription reads:")
    print("\n'I have no mouth, yet I sing.\nI have no hands, yet I climb.\nI have no wings, yet I rise.\nWhat am I?'")

    answer = input("\nWhat is your answer? ").strip().lower()

    if answer in ["smoke", "a flame", "fire"]:
        print("\nThe runes dim, and a hidden door slides open, revealing the path ahead.")
    else:
        print(
            "\nThe runes glow brighter, their heat searing the air. A disembodied voice intones: 'That is \n"
            "not the answer.'")
        print("You must try again.")
        return essenceoflight(player)  # Restart trial

    print("\n--- Trial 3: The Corrupted High Priestess ---")
    print(
        "You enter the final chamber, where the air is thick with both light and shadow. At its center stands the \n"
        "High Priestess.")
    print(
        "Once a beacon of hope, she is now consumed by corruption. Her form flickers between radiant beauty and \n"
        "dark horror.")
    print(
        "She speaks, her voice echoing with two tones: 'You come seeking the Essence, but you shall find only despair.'")

    print("\nThe battle begins!")
    print(
        "The High Priestess wields powerful light-based attacks to blind and disorient you, followed by shadow \n"
        "strikes to exploit your vulnerabilities.")
    print(
        "She summons radiant constructs to aid her and uses area-of-effect spells that force you to constantly adapt.")

    story_boss_encounter(player, "Corrupted High Priestess")
    if player.hp >= 0:
        print(
            "\nAs the High Priestess falls, the room’s corruption begins to dissipate. She collapses to her knees, \n"
            "her voice now soft and clear.")
        print("'Thank you,' she whispers. 'The light... it returns.'")
        print("With her final breath, she reveals the location of the Essence of Light.")
        print(
            "\nYou approach the Essence, a radiant crystal pulsing with pure energy. As you reach out, it fills \n"
            "you with warmth and hope.")
        print("The Essence of Light is yours.")
    else:
        essenceoflight(player)


def shardofpureshadow(player):
    print("\n--- Quest: The Shard of Pure Shadow ---")
    print(
        "Your journey to the Abyss of Nightmares begins as you step into a realm where reality twists and \n"
        "fear becomes tangible.")
    print("The air is cold, and your surroundings shift constantly, making it difficult to trust your senses.")
    print("Shadows dance and whisper around you, each one threatening to consume your sanity.")

    print("\nAt the entrance, a hooded figure appears, offering cryptic advice.")
    print("'The Abyss tests the mind more than the body. Face your fears, or be lost forever.'")
    print("With those words, the figure vanishes, leaving you to navigate the shifting corridors of the Abyss.")

    print("\nThe Abyss presents you with three manifestations of your deepest fears:")
    print("1. A loved one, twisted and blaming you for past failures.")
    print("2. A version of yourself, consumed by darkness and despair.")
    print("3. A towering nightmare creature, its form constantly changing to embody terror.")

    choice = input("Do you confront the loved one (1), your darker self (2), or the nightmare creature (3)? ")

    if choice == "1":
        print(
            "\nYou confront the twisted figure, realizing it is a manifestation of guilt. Through compassion \n"
            "and resolve, you dispel the illusion.")
    elif choice == "2":
        print(
            "\nFacing your darker self is harrowing. It mocks your weaknesses and fears, but you stand firm, \n"
            "embracing your flaws.")
    elif choice == "3":
        print(
            "\nThe nightmare creature attacks")
        story_boss_encounter(player, "Shadow")
        if player.hp <= 0:
            shardofpureshadow(player)
    else:
        print("\nInvalid choice. The Abyss warps around you. Try again.")
        shardofpureshadow(player)

    print(
        "\nAt the heart of the Abyss, you find the Shard of Pure Shadow. It pulses with dark energy, yet you sense \n"
        "it holds great power.")
    print("As you claim it, the shadows recede slightly, and a sense of accomplishment fills you.")


def journey_to_mountain(player):
    print("\n--- The Journey to the Mountain: The Final Peak ---")
    print("Your destination is the Lost City of Souls, hidden deep within the Final Peak.")
    print("The path is fraught with perils, as the Voidspawn's corruption spreads to the wilderness.")

    print("\nYour first challenge is the **Howling Gorge**, where vicious winds and unstable cliffs threaten your \n"
          "progress.")
    choice = input("Do you climb the cliffs directly (1) or take a longer, safer detour through the forest (2)? ")

    if choice == "1":
        print("\nYou scale the cliffs, but loose rocks and strong winds make it treacherous.")
        player.hp -= 10
        print(f"Your health is now {player.hp}.")
    elif choice == "2":
        print("\nThe forest path is safer but takes much longer, leaving you vulnerable to Voidspawn patrols.")
        story__encounter(player, "Voidspawn Minion")
        story_monster_encounter(player, "Voidspawn Minion")
    else:
        print("\nInvalid choice. The gorge grows more dangerous. Try again.")
        journey_to_mountain(player)

    print("\nYou survive the gorge, only to face the **Icebound Caverns**, a network of freezing tunnels \n"
          "leading to the peak.")
    choice = input("Do you light a torch to keep warm (1) or rely on your endurance to push through (2)? ")

    if choice == "1":
        print("\nThe torch keeps you warm, but its light attracts Frost Shades.")
        story_boss_encounter(player, "Frost Shades")
        story_boss_encounter(player, "Frost Shades")
        story_boss_encounter(player, "Frost Shades")
    elif choice == "2":
        print("\nYou conserve your resources, but the freezing temperatures sap your strength.")
        player.hp -= 15
        print(f"Your health is now {player.hp}.")
    else:
        print("\nInvalid choice. The caverns grow more treacherous. Try again.")
        journey_to_mountain(player)

    print("\nFinally, you reach the peak, where the Lost City of Souls awaits, its gates glowing faintly in the \n"
          "moonlight.")

def reforge_soulstone(player):
    print("\n--- Reforging the Soulstone ---")
    print("The Lost City of Souls is eerily silent, its streets lined with spectral figures.")
    print("At its center lies the Kingsguard, an ancient castle that holds the forge required to reforge the Soulstone.")

    print("\nYou enter the Kingsguard, but the castle is protected by spectral knights who test your resolve.")
    story_boss_encounter(player, "Spectral Knight")
    story_boss_encounter(player, "Spectral Knight")
    print("With the knights defeated, you make your way to the inner sanctum.")

    print("\nIn the sanctum, you find the Soulforge—a massive, glowing anvil surrounded by runic carvings.")
    print("You place the shards and items on the forge, but the reforging ritual requires an energy source.")

    print("\nAndelari’s words echo in your mind: 'The reforging requires a great sacrifice. Will it be your life \n"
          "force or another's?'")
    choice = input("Do you sacrifice a portion of your own soul (1) or summon an ally to offer their life force (2)? ")

    if choice == "1":
        print("\nYou channel your own life force into the Soulforge. The pain is excruciating, and you feel a part of\n"
              "your soul fading.")
        player.hp -= 20
        print(f"Your health is now {player.hp}. The Soulstone is reforged, glowing with renewed power.")
    elif choice == "2":
        print("\nYou summon a trusted ally and ask for their sacrifice. They willingly offer their life, and the \n"
              "Soulstone is reforged.")
        print("However, the guilt weighs heavily on you. You’ve paid a heavy price for victory.")
    else:
        print("\nInvalid choice. The ritual stalls. Try again.")
        reforge_soulstone(player)

    print("\nAs the Soulstone gleams with newfound energy, the Voidspawn senses its power and prepares for the final \n"
          "confrontation.")
    print("Your next task lies at the heart of the cursed lands, where the Voidspawn awaits.")

def chapter5_part1(player):
    print("\n--- Chapter 5: The Final Confrontation ---")
    print("-------------- Part 1 --------------")
    print("With the reforged Soulstone in your possession, you steel yourself for the final journey.")
    print("The cursed lands stretch before you, a desolate wasteland of jagged rocks and swirling shadows.")
    print("Whispers of despair and anger echo through the air, a constant reminder of the Voidspawn's power.")

    # Companions or Solo
    if player.inventory["allies"]:
        print("\nYour companions gather around you, their faces grim but determined.")
        print("'We’ve come this far together,' one says, gripping their weapon. 'Let’s end this.'")
    else:
        print("\nThe weight of the reforged Soulstone feels heavier in your hand as you realize this burden is yours alone.")
        print("You take a deep breath, knowing that your decisions have brought you here.")

    # First Challenge: The Weeping Forest
    print("\n--- The Weeping Forest ---")
    print("You enter a twisted forest, its skeletal trees dripping with black ichor. The air grows colder with each step.")
    print("The forest seems alive, its branches clawing at you, and faint cries of agony echo all around.")
    weeping_forest(player)
    player.gain_xp(250)

    # Second Challenge: The Abyssal Crossing
    print("\n--- The Abyssal Crossing ---")
    print("You reach a massive chasm, its depths swirling with darkness. A series of ancient stone platforms float precariously across.")
    print("The platforms shift and crumble as you step on them, and spectral winds howl through the abyss.")
    abyssal_crossing(player)
    player.gain_xp(250)

    # Third Challenge: The Valley of Despair
    print("\n--- The Valley of Despair ---")
    print("The cursed lands rise into a valley where despair itself seems to take physical form. The air grows thick, and every step feels like a monumental effort.")
    valley_of_despair(player)
    player.gain_xp(250)

    print("\nYou climb out of the valley, battered but triumphant. Ahead, the Voidspawn's fortress looms, its towering spires piercing the dark sky.")
    print("\nAs you approach the fortress, a massive gate of obsidian opens before you, revealing the heart of the cursed lands.")
    print("'Come, little hero,' a deep, otherworldly voice rumbles. 'Let us end this.'")

    chapter5_part2(player)


def weeping_forest(player):
    print("\nChallenge: Navigate the forest without succumbing to its illusions.")
    while True:
        print("\n1. Face shadows of your past mistakes.")
        print("2. Follow the light of the Soulstone to find the true path.")
        print("3. Defend against an ambush of Voidspawn minions.")
        choice = input("Choose your action (1/2/3): ")
        if choice == "1":
            print("The shadows taunt and accuse you, but you find the strength to resist their lies.")
            if player.attack_power >= 10:
                print("Your resolve holds firm, and the shadows dissipate.")
                break
            else:
                print("The shadows overwhelm you, and you lose some of your strength.")
                player.hp -= 10
        elif choice == "2":
            print("You focus on the Soulstone, its light cutting through the darkness.")
            if player.magic_power >= 12:
                print("The true path reveals itself, and you move forward.")
                break
            else:
                print("The path shifts and confuses you, forcing you to start over.")
        elif choice == "3":
            print("Voidspawn minions emerge, clawing at you from the shadows!")
            story_monster_encounter(player, "Voidspawn Minion")
            if player.hp <= 0:
                weeping_forest(player)
            else:
                break
        else:
            print("Invalid choice. Try again.")


def abyssal_crossing(player):
    print("\nChallenge: Cross the chasm while avoiding falling into the abyss.")
    while True:
        print("\n1. Leap from platform to platform.")
        print("2. Fight off spectral creatures rising from the chasm.")
        print("3. Solve the glowing rune puzzle to activate a bridge.")
        choice = input("Choose your action (1/2/3): ")
        if choice == "1":
            print("You leap from one unstable platform to the next.")
            if player.dexterity >= 14:
                print("Your leaps are sure-footed, and you make it across.")
                break
            else:
                print("A platform crumbles beneath you, and you barely hang on.")
                player.hp -= 10
        elif choice == "2":
            print("Spectral creatures swarm around you!")
            story_boss_monster(player, "Spectral Knight")
            if player.hp >= 0:
                abyssal_crossing(player)
            else:
                break
        elif choice == "3":
            print("You study the runes glowing on a nearby platform.")
            if player.magic_power >= 13:
                print("You solve the puzzle, and a glowing bridge forms.")
                break
            else:
                print("The runes remain cryptic, and the chasm threatens to claim you.")
        else:
            print("Invalid choice. Try again.")


def valley_of_despair(player):
    print("\nChallenge: Resist the overwhelming despair and press forward.")
    while True:
        print("\n1. Confront the visions of failure and loss.")
        print("2. Battle the shadow beasts that guard the valley.")
        print("3. Navigate the collapsing terrain.")
        choice = input("Choose your action (1/2/3): ")
        if choice == "1":
            print("The visions haunt you, showing all that you could lose.")
            if player.attack_power >= 18:
                print("You banish the visions and push onward.")
                break
            else:
                print("The despair clings to you, sapping your strength.")
                player.hp -= 15
        elif choice == "2":
            print("Massive shadow beasts block your path, their roars shaking the ground.")
            player_monster_encounter(player, "Shadow")
            if player.hp >= 0:
                valley_of_despair(player)
            else:
                break
        elif choice == "3":
            print("The ground crumbles beneath your feet, and you scramble for stable footing.")
            if player.dexterity >= 15:
                print("You find your footing and avoid the collapse.")
                break
            else:
                print("The collapse nearly claims you, and you are injured in the process.")
                player.hp -= 10
        else:
            print("Invalid choice. Try again.")


def chapter5_part2(player):
    print("\n--- Chapter 5: The Final Battle ---")
    print(
        "You step into the heart of the fortress. The Voidspawn looms before you, a monstrous being of shadow and chaos.")
    print("Its form shifts and twists, impossible to comprehend fully. Eyes like black stars pierce your soul.")

    if player["allies"]:
        print(
            "\nYour allies rally beside you, shouting words of encouragement. Together, you prepare for the fight of your lives.")
    else:
        print(
            "\nYou steel yourself, knowing this is your fight alone. The reforged Soulstone glows brightly \n"
            "in your hand.")

    # Final battle mechanics
    print("You wont win. I was created to never lose! Says the Voidspawn in a cocky manner.")
    print("It's voice is haunting and demonic. You stand strong and reply strongly")
    print("I will never lose to evil, you are the darkness and I am the light")
    story_boss_encounter(player, "VoidSpawn")

    outcome = final_choice(player)

    if outcome == "seal":
        seal_voidspawn(player)
    elif outcome == "destroy":
        destroy_voidspawn(player)
    elif outcome == "join":
        join_voidspawn(player)


def final_choice(player):
    print(
        "\nThe Voidspawn falters, its strength waning. You hold the reforged Soulstone, its power surging through you.")
    print("The moment of decision is at hand. What will you do?")

    print("\n1. Seal the Voidspawn: Use the Soulstone to banish it back into the void.")
    print("2. Destroy the Voidspawn: Sacrifice yourself to annihilate it completely.")
    print("3. Join the Voidspawn: Embrace the darkness and become its ally.")

    choice = input("Enter your choice (1/2/3): ").strip()
    if choice == "1":
        return "seal"
    elif choice == "2":
        return "destroy"
    elif choice == "3":
        return "join"
    else:
        print("\nInvalid choice. Try again.")
        return final_choice(player)


def seal_voidspawn(player):
    print("\n--- Ending: Sealing the Voidspawn ---")
    print("You channel the power of the Soulstone, its light growing blindingly bright.")
    print("The Voidspawn roars in fury as it is pulled into the void, sealed away once more.")
    if player.inventory["dark power"]:
        print(
            "\nThough you saved the land, whispers of your unholy alliances linger. The people remember you as \n"
            "both savior and accursed.")
        player.gain_xp(2500)
    else:
        print("\nThe land is saved, and your name is etched into legend as a beacon of hope.")
    print("You leave the cursed lands behind, knowing your actions have secured peace.")
    player.gain_xp(2500)


def destroy_voidspawn(player):
    print("\n--- Ending: Destroying the Voidspawn ---")
    print(
        "You pour every ounce of your being into the Soulstone, unleashing a wave of light that obliterates the Voidspawn.")
    print("As the darkness fades, so does your strength. You collapse, your soul merging with the light.")
    print(
        "\nThe world is saved, but you are no more. Songs of your sacrifice echo through the ages, a martyr \n"
        "who gave everything for peace.")
    player.gain_xp(2500)


def join_voidspawn(player):
    print("\n--- Ending: Joining the Voidspawn ---")
    print("You lower the Soulstone and step forward, extending your hand to the Voidspawn.")
    print("'I see now,' you say. 'The world is broken, and only you can reshape it.'")
    print("\nThe Voidspawn accepts you, and together, you merge into a being of unparalleled power.")
    print("The world falls into despair under your rule, but to you, it is a necessary sacrifice for a new order.")
    print("Your name becomes a curse, feared and hated across the land.")
    player.gain_xp(2500)

    print("\n--- Transformation ---")
    print(
        "Your form twists and changes, infused with the Voidspawn’s essence. You have become something greater, something more...")

    # Transition to character creation
    print(
        "\nAs a Voidspawn, you now have the opportunity to create a new character embodying your dark transformation.")
    print("This new character will have unique abilities and traits tied to the Voidspawn's power.")

    print("\n--- New Character Creation ---")
    name = input("Enter the name of your new Voidspawn character: ")
    player.character_class = "Voidspawn Ascendant"  # Special class name
    print("\nYou have chosen to become a Voidspawn Ascendant!")


def cave_depth():
    # Randomly determine the number of cave rooms (between 1 and 5, for example)
    num_rooms = random.randint(1, 5)

    # Create a list to store cave rooms
    cave_rooms = []

    # Descriptions of possible cave rooms
    room_descriptions = [
        "a dark, damp chamber with water dripping from the ceiling",
        "a narrow passageway filled with stalactites and stalagmites",
        "a room with ancient carvings on the walls, depicting forgotten gods",
        "a cavernous hall with a large underground lake, its waters eerily still",
        "a small, musty chamber filled with the remains of adventurers long gone",
        "a room with flickering torches and a mysterious chest in the corner",
        "a tunnel leading deeper into the darkness, the air thick with the smell of decay",
        "a chamber filled with strange, glowing mushrooms that light the path",
        "a room where the walls seem to move, as though alive with some dark magic",
        "a narrow cave passage blocked by a boulder, with a strange glimmer behind it"
    ]

    # Randomly generate rooms for the cave
    for room_number in range(1, num_rooms + 1):
        room_description = random.choice(room_descriptions)
        cave_rooms.append(f"Cave Room {room_number}: {room_description}")

    # Return the generated cave rooms
    return cave_rooms


# Area Exploring
def explore_area(player, area):
    exit_area = False  # Variable to control when to exit the area
    while not exit_area:  # Stay in the area until the player chooses to leave
        if area == "town":
            player.current_location = area
            print("You're in a Town with merchants."
                  "You can walk around to find shops, merchants, Town Hall, and more!")
            # Random NPC encounter in town
            town_npc_encounter = random.randint(1, 4)  # 1 in 4 chance for an NPC encounter
            if town_npc_encounter == 1:
                print("You meet an NPC!")
                npc = random.choice([npc_merchant, npc_traveler])
                npc.interact(player)
            else:
                action = input("Do you want to (explore/leave)? ").lower()
                if action == "shop":
                    shop(player)
                elif action == "explore":
                    print("You explore the town streets. Where do you want to go?")
                    explore_choice = input("Choose to go to (market/blacksmith/inn/alley/library): ").lower()

                    # Explore Market
                    if explore_choice == "market":
                        print("You enter the bustling market, filled with merchants selling various goods.")
                        market_event = random.randint(1, 3)
                        if market_event == 1:
                            print("A merchant offers you a to go to his shop to buy a mystic talisman")
                            rare_item = Item("Mystic Talisman", "magic", 100)
                            if player.gold >= 100:
                                buy_item = input(
                                    f"Do you want to buy the {rare_item.name} for 100 gold? (yes/no): ").lower()
                                if buy_item == "yes":
                                    player.gold -= 100
                                    player.inventory.append(rare_item)
                                    print(f"You bought the {rare_item.name}.")
                            else:
                                print("Merchant: Sorry, you don't have enough gold to purchase this.")
                        else:
                            print("You browse the stalls but find nothing of interest.")
                        if market_event == 2 or 3:
                            print("You find a shop, it's entrance made of arches and aged wood.")
                            enter = input("Would you like to enter(yes/no)").lower()
                            if enter == "yes":
                                shop(player)
                            elif enter == "no":
                                continue

                    # Explore Blacksmith
                    elif explore_choice == "blacksmith":
                        print("You enter the blacksmith's forge. The heat is intense as you see weapons being crafted.")
                        print("Hello sir. How may I be of use to you today?")

                        while True:
                            decision = input(
                                "1. Buy Weapons\n2. Repair Armor\n3. Salvage Items\n4. Sell\n5. Leave\n").strip()

                            # Buying Weapons
                            if decision == "1":
                                weapons_for_sale = [
                                    Item("Short Sword", "attack", 20),
                                    Item("Longsword", "attack", 30),
                                    Item("Shield", "block", 20),
                                    Item("Short Bow", "attack", 20),
                                    Item("Long Bow", "attack", 30),
                                    Item("Arrow", "attack", 5),
                                    Item("Staff", "attack", 15),
                                    Item("Leather Armor", "low_armor", 20),
                                    Item("Chain Mail", "med_armor", 40),
                                    Item("Paladin Armor", "high_armor", 70)
                                ]

                                print("Weapons and Armor for Sale:")
                                for i, weapon in enumerate(weapons_for_sale):
                                    print(f"{i + 1}. {weapon.name} - {weapon.cost} gold")

                                # Player buys an item
                                choice = input(
                                    "Enter the number of the item you wish to buy (or 'cancel' to go back): ").strip()
                                if choice.isdigit() and 1 <= int(choice) <= len(weapons_for_sale):
                                    selected_item = weapons_for_sale[int(choice) - 1]
                                    if player.gold >= selected_item.cost:
                                        player.gold -= selected_item.cost
                                        player.inventory.append(selected_item)
                                        print(f"You bought the {selected_item.name} for {selected_item.cost} gold.")
                                    else:
                                        print("You don't have enough gold.")
                                elif choice.lower() == "cancel":
                                    continue

                            # Repair Armor
                            elif decision == "2":
                                print("You ask the blacksmith to repair your armor.")
                                armor_items = [item for item in player.inventory if "armor" in item.type]
                                if armor_items:
                                    print("The blacksmith can repair the following armor in your inventory:")
                                    for i, armor in enumerate(armor_items):
                                        print(f"{i + 1}. {armor.name}")

                                    repair_choice = input(
                                        "Enter the number of the armor to repair (or 'cancel' to go back): ").strip()
                                    if repair_choice.isdigit() and 1 <= int(repair_choice) <= len(armor_items):
                                        selected_armor = armor_items[int(repair_choice) - 1]
                                        repair_cost = 10  # Arbitrary cost for repairs
                                        if player.gold >= repair_cost:
                                            player.gold -= repair_cost
                                            print(
                                                f"The blacksmith repairs your {selected_armor.name} for {repair_cost} gold.")
                                            # Optionally, restore some stats if using durability mechanics
                                        else:
                                            print("You don't have enough gold to repair your armor.")
                                    elif repair_choice.lower() == "cancel":
                                        continue
                                else:
                                    print("You don't have any armor to repair.")

                            # Salvage Items
                            elif decision == "3":
                                print("You can salvage certain items for materials or gold.")
                                salvageable_items = [item for item in player.inventory if
                                                     "weapon" in item.type or "armor" in item.type]
                                if salvageable_items:
                                    print("You can salvage the following items:")
                                    for i, item in enumerate(salvageable_items):
                                        print(f"{i + 1}. {item.name}")

                                    salvage_choice = input(
                                        "Enter the number of the item to salvage (or 'cancel' to go back): ").strip()
                                    if salvage_choice.isdigit() and 1 <= int(salvage_choice) <= len(salvageable_items):
                                        selected_item = salvageable_items[int(salvage_choice) - 1]
                                        player.inventory.remove(selected_item)
                                        # Random amount of gold or material for # salvaging
                                        salvage_reward = random.randint(5,15)
                                        player.gold += salvage_reward
                                        print(
                                            f"You salvaged the {selected_item.name} and received {salvage_reward} gold.")
                                    elif salvage_choice.lower() == "cancel":
                                        continue
                                else:
                                    print("You don't have any items to salvage.")

                            # Selling Items
                            elif decision == "4":
                                print("You can sell items from your inventory.")
                                if player.inventory:
                                    for i, item in enumerate(player.inventory):
                                        print(f"{i + 1}. {item.name} - Sell value: {item.cost // 2} gold")

                                    sell_choice = input(
                                        "Enter the number of the item to sell (or 'cancel' to go back): ").strip()
                                    if sell_choice.isdigit() and 1 <= int(sell_choice) <= len(player.inventory):
                                        selected_item = player.inventory[int(sell_choice) - 1]
                                        sell_value = selected_item.cost // 2  # Sell items for half their cost
                                        player.gold += sell_value
                                        player.inventory.remove(selected_item)
                                        print(f"You sold the {selected_item.name} for {sell_value} gold.")
                                    elif sell_choice.lower() == "cancel":
                                        continue
                                else:
                                    print("You don't have any items to sell.")

                            # Leave
                            elif decision == "5":
                                print("You leave the blacksmith.")
                                break

                            else:
                                print("Invalid option. Please choose a number from the list.")

                    # Explore Inn
                    elif explore_choice == "inn":
                        print("You enter the local inn, a cozy place filled with travelers.")
                        inn_event = random.randint(1, 3)
                        if inn_event == 1:
                            print("You overhear rumors of a mystical and perilous Quest.")
                            choice1 = input("You can ask about it or ignore it.(ask/ignore): ").lower()
                            if choice1 == "ask":
                                print("Stranger: There's an evil around.")
                                print("You: Well what is it.")
                                print("Stranger: I don't fully understand.")
                                print("Stranger: Go to Eldergrove they'll tell ya more!")
                                Story = True
                                main_story1(player)
                            elif choice1 == "ignore":
                                Story = False
                                sleep = input("do you want to (sleep, eat, talk, or leave): ").lower()
                                if sleep == "sleep":
                                    print("You take a moment to rest and recover.")
                                    player.hp = min(player.hp + random.randint(10, 20), player.max_hp)
                                    print(f"You now have {player.hp} HP.")
                                elif sleep == "eat":
                                    print("You eat some food that has given you more energy")
                                    player.hp = min(player.hp + random.randint(5, 10), player.max_hp)
                                    print(f"You now have {player.hp} HP.")
                                elif sleep == "talk":
                                    npc = random.choice([npc_traveler, npc_wandering_mage, npc_merchant])
                                    npc.interact(player)
                                elif sleep == "leave":
                                    print("you leave the inn")
                                    continue
                        else:
                            sleep = input("do you want to (sleep, eat, talk, or leave): ").lower()
                            if sleep == "sleep":
                                print("You take a moment to rest and recover.")
                                player.hp = min(player.hp + random.randint(10, 20), player.max_hp)
                                print(f"You now have {player.hp} HP.")
                            elif sleep == "eat":
                                print("You eat some food that has given you more energy")
                                player.hp = min(player.hp + random.randint(5, 10), player.max_hp)
                                print(f"You now have {player.hp} HP.")
                            elif sleep == "talk":
                                npc = random.choice([npc_traveler, npc_wandering_mage, npc_merchant])
                                npc.interact(player)
                            elif sleep == "leave":
                                print("you leave the inn")
                                continue

                    # Explore Alley
                    elif explore_choice == "alley":
                        print("You sneak into a narrow alley. It's dark and shady.")
                        alley_event = random.randint(1, 3)
                        if alley_event == 1:
                            print("You encounter a shady figure offering you a secret deal.")

                        else:
                            print("You find nothing here.")

                    # Explore Library
                    elif explore_choice == "library":
                        print("You step into the town library, filled with ancient books and scrolls.")
                        library_event = random.randint(1, 3)
                        if library_event == 1:
                            print("You find an ancient book containing a mysterious spell.")
                            # Add spell or lore discovery

                elif action == "town hall":
                    print("You walk to the Town Hall, where the town officials work.")
                    # Town Hall events like meeting officials, starting new quests

                elif action == "tavern":
                    print("You enter the lively tavern, full of adventurers and locals.")
                    # Tavern events like hearing rumors, meeting NPCs

                elif action == "quest":
                    if not player.active_quests:
                        quest = random.choice(quests)
                        player.accept_quest(quest)
                    else:
                        print("You already have an active quest.")
                elif action == "leave":
                    exit_area = True

        elif area == "forest":
            print("\nYou step into a dense forest, filled with the sounds of nature.")
            print("You can search for herbs, encounter wild creatures, or complete your quest.")
            action = input("Do you want to (search/quest/leave)? ").lower()
            if action == "search":
                find_items = ("Herbs", "Nothing", "Attack Elixir", "Rusty Sword")
                item = random.choice(find_items)
                if item == "Herbs":
                    print("You found some rare herbs that can be used for healing!")
                    player.inventory.append(Item("Herbal Remedy", "heal", 10))
                    player.check_quest_progress("gather_herbs")
                if item == "Attack Elixir":
                    print("You found an Attack Elixir!")
                    player.inventory.append(Item("Attack Elixir", "attack_boost", 20))
                if item == "Rusty Sword":
                    print("You found a rusty sword!")
                    player.inventory.append(Item("Rusty Sword", "none", 5))
                if item == "Nothing":
                    print("you found nothing")
            elif action == "quest":
                quest_random = random.radient(1, 100)
                if quest_random <= 25:
                    player.check_quest_progress("find_treasure")
                    print("You searched the forest and found the hidden treasure!")
            elif action == "leave":
                exit_area = True

        elif area == "cave":
            print("\nYou find a dark cave, its entrance ominous and foreboding.")
            cave_rooms = cave_depth()
            current_room = 0  # Start at the first room of the cave

            while not exit_area and current_room < len(
                    cave_rooms):  # Explore until all rooms are done or the player chooses to leave
                room = cave_rooms[current_room]
                print(room)
                print("You can explore deeper, rest outside, or complete your quest.")
                action = input("Do you want to (explore/rest/quest/leave)? ").lower()
                if action == "explore":
                    find_items = ("treasure chest", "Skeleton", "Traveler")
                    item = random.choice(find_items)
                    if item == "treasure chest":
                        print("You venture deeper into the cave and find a treasure chest!")
                        player.inventory.append(Item("Treasure Chest", "none", 0))
                    elif item == "Skeleton":
                        print("You go deeper into the cave and find a skeleton lying on the ground.")
                        choice = input("What do you do? (leave it alone/inspect/take a bone): ").lower()

                        if choice == "leave it alone":
                            print("You decide not to disturb the skeleton and move on.")

                        elif choice == "inspect":
                            print("You carefully inspect the skeleton and notice it's wearing an old, rusted armor.")
                            further_choice = input(
                                "Do you want to take the armor or search the body? (take/search/leave): ").lower()

                            if further_choice == "take":
                                print("You take the rusted armor. It's not in great shape, but it might come in handy.")
                                player.inventory.append(Item("Rusted Armor", "defense", 1))
                            elif further_choice == "search":
                                print(
                                    "As you search the skeleton, you find an ancient coin pouch hidden beneath its "
                                    "bones.")
                                player.inventory.append(
                                    Item("Ancient Coin Pouch", "gold", 50))  # Example of adding gold
                                found_gold = random.randint(5, 50)
                                player.gold += found_gold
                                print(f"you found {found_gold} gold")
                            else:
                                print("You leave the skeleton as it is.")

                        elif choice == "take a bone":
                            print("You carefully pick up one of the bones from the skeleton.")
                            print("Suddenly, the life forces from the bones cause an enemy to appear!")
                            monster_encounter(player)  # Start an encounter
                        else:
                            print("You hesitate and decide to leave the skeleton undisturbed.")
                    elif item == "Traveler":
                        print("You meet a wandering NPC!")
                        npc = random.choice([npc_traveler, npc_wandering_mage, npc_merchant])
                        npc.interact(player)
                elif action == "rest":
                    print("You take a moment to rest and recover.")
                    player.hp = min(player.hp + random.randint(10, 20), player.max_hp)
                    print(f"You now have {player.hp} HP.")
                elif action == "quest":
                    quest_random = random.randint(1, 100)
                    if quest_random <= 25:
                        print("You encountered the Cave Beast!")
                        monster_encounter(player)
                        player.check_quest_progress("defeat_cave_monster")
                elif action == "leave":
                    exit_area = True
                    break

                current_room += 1  # Move to the next room in the cave after each exploration

            if current_room == len(cave_rooms):
                print("You have explored all the rooms in the cave.")
            else:
                print(f"You leave the cave after exploring {current_room} room(s).")
        elif area == "road":
            print("You found a road leading to something in the distance.")
            print("You can walk up the road or rest on the side.")
            action = input("Do you want to (walk/rest/leave)? ").lower()
            if action == "walk":
                print("You walk up the road.")
                exit_area = True
            elif action == "rest":
                print("You take a moment to rest and recover.")
                player.hp = min(player.hp + random.randint(10, 20), player.max_hp)
                print(f"You now have {player.hp} HP.")
            elif action == "leave":
                exit_area = True
                break
        elif area == "ruins":
            ruins = ("Castle", "Town", "Watchtower")
            if random.random() < 0.65:
                selected_ruin = random.choice(ruins)
                print(f"You found Ancient {selected_ruin} Ruins.")
                print("You can search the place, leave, or complete your quest.")
                action = input("Do you want to (search/quest/leave)? ").lower()
                if action == "search":
                    ruin_description = ("some writing on the walls", "a spell circle", "nothing", "a skeleton")
                    selected_description = random.choice(ruin_description)
                    print(f"You found {selected_description}.")
                    quest_random = random.randint(1, 100)
                    if quest_random <= 25:
                        player.check_quest_progress("Ancient Ruins Discovery")
                elif action == "quest":
                    quest_random = random.randint(1, 100)
                    if quest_random <= 25:
                        print("You encountered the Bandit King!")
                        monster_encounter(player)
                        player.check_quest_progress("defeat_bandit_king")
                elif action == "leave":
                    exit_area = True
            else:
                print("What you thought were ruins was actually a mirage.")
                exit_area = False

        # Encounter chance for all areas except town
        if area != "town":
            encounter_chance = random.randint(1, 100)
            if encounter_chance <= 20:
                print("A monster appears!")
                monster_encounter(player)
            elif encounter_chance <= 15:  # 15% chance for an NPC encounter
                print("You meet a wandering NPC!")
                npc = random.choice([npc_traveler, npc_wandering_mage])
                npc.interact(player)

    print(f"You leave the {area}.")

    # After exploring, check if an item is found
    item_found = find_item()
    if item_found:
        player.inventory.append(item_found)
        print(f"You found a {item_found.name}!")
    else:
        print(".")


# Shopping function
def shop(player):
    items_available = [
        Item("Health Potion", "heal", 20),
        Item("Attack Elixir", "attack_boost", 30),
        Item("Leather Armor", "armor", 50),
        Item("Longsword", "weapon", 40)
    ]

    print("Welcome to the shop!")
    print(f"You have {player.gold} gold.")

    while True:
        print("\nAvailable items:")
        for index, item in enumerate(items_available):
            print(f"{index + 1}: {item.name} (Effect: {item.effect}) - {item.cost} gold")
        print("0: Exit shop")
        choice = input("Choose an item to buy (0 to exit): ")

        try:
            choice = int(choice)
            if choice == 0:
                print("Exiting shop.")
                break
            elif 0 < choice <= len(items_available):
                selected_item = items_available[choice - 1]
                player.buy_item(selected_item)
            else:
                print("Invalid choice. Please select a valid option.")
        except ValueError:
            print("Invalid input. Please enter a number.")


# Show stats for character in game
def show_class_stats(class_name, player):
    # Example class stats; replace these with your actual class stats
    class_stats = {
        "Fighter": {
            "Abilities": ("Level 1: Shield Bash. "
                          "Level 2: Cleave. "
                          "Level 3: Battle Cry. "
                          "Level 4: Defensive Stance. "
                          "Level 5: Whirlwind Attack.")
        },
        "Wizard": {
            "Abilities": ("Level 1: Magic Missile. "
                          "Level 2: Mage Armor. "
                          "Level 3: Fireball. "
                          "Level 4: Invisibility. "
                          "Level 5: Lightning Bolt.")
        },
        "Rogue": {
            "Abilities": ("Level 1: Sneak Attack. "
                          "Level 2: Cunning Action. "
                          "Level 3: Evasion. "
                          "Level 4: Uncanny Dodge. "
                          "Level 5: Assassinate.")
        }
    }

    # Get the class stats from the dictionary
    stats = class_stats.get(class_name, "Class not found.")

    if isinstance(stats, dict):
        print(f"{class_name} Stats:")
        for key, value in stats.items():
            print(f"- {key}: {value}")
    else:
        print(stats)


# Game function
def game():
    Story = False
    print("Welcome to FateBound!")
    print("Type 'How to Play' for instructions.")
    print("Type 'Stats' then a Class to see class descriptions and stats. Ex. 'Stats Fighter'.")
    print("Type 'exit' to quit.")

    player = None  # Initialize player outside the loop

    while player is None:
        input_choice = input("\nWhat class will you choose? (Fighter/Wizard/Rogue) or type a command: ").lower()

        if input_choice == "exit":
            print("Exiting game. Goodbye!")
            return
        elif input_choice == "how to play":
            print("""
            How to Play:
            - Choose a class: Fighter, Wizard, or Rogue.
            - Type your class then stats while playing to see your stats
            - Explore different areas: town, forest, cave, Etc.
            - Engage in encounters like monster battles or item discoveries.
            - Manage your health (HP), gold, and inventory.
            - Level up and get new abilities, more health, and Power.
            - Type in the words the system gives you to progress.
            - Visit town to shop for items and hear rumors.
            - Your goal: survive and explore as long as possible!
            """)
        elif input_choice.startswith("stats"):
            if player is None:
                # Show stats for all classes if no player is created
                class_name = input_choice.split()[1].capitalize() if len(input_choice.split()) > 1 else ""
                if class_name in ["Fighter", "Wizard", "Rogue"]:
                    show_class_stats1(class_name)
                else:
                    print("Invalid class name. Please enter 'Fighter', 'Wizard', or 'Rogue'.")
            else:
                # Show stats for the player's class
                print(f"Showing stats for {player.character_class}:")
                show_class_stats1(player.character_class)
        elif input_choice in ["fighter", "wizard", "rogue"]:
            if player is None:  # Allow class selection only if player is not created
                name = input("Enter your character's name: ")
                player = Character(name, input_choice.capitalize())
                print(f"Welcome, {player.name} the {player.character_class}!")
            else:
                print("You have already chosen a class. You cannot change it now.")
        else:
            print("Invalid choice. Please choose a valid class or type 'exit'.")

            # Main game loop after class selection
        if player is not None:
            while player.hp > 0:
                play_main_story = input("Do you want to play the main story(yes/no): ").lower()
                if play_main_story == "yes":
                    main_story1(player)
                elif play_main_story == "no":
                    Story = False

                while not Story:
                    input_choice = input("\nYou've come to a crossroad. "
                                         "What would you like to do next? (explore, stats, exit, or rest): ").lower()

                    if input_choice == "exit":
                        print("Exiting game. Goodbye!")
                        return
                    elif input_choice == "stats":
                        print(f"Your current stats, {player.name}:")
                        player.show_stats()

                        # Pass the appropriate class_name and player object to show_class_stats
                        class_name = player.character_class
                        show_class_stats(class_name, player)

                    elif input_choice == "explore":
                        exit_area = False  # Initialize the exploration loop control
                        while not exit_area:  # Stay in the area until the player chooses to leave
                            area = random_area()
                            if area:
                                print(f"\nYou discover a {area} nearby.")
                                explore_area(player, area)
                            else:
                                print("There's nothing around you to explore. So you walk around.")

                            # Ask if the player wants to continue exploring the same area
                            stay = input("Do you want to keep exploring this area (yes/no)? ").lower()
                            if stay == "no":
                                exit_area = True  # Break the loop and leave the area
                            elif stay == "yes":
                                exit_area = False  # Keep exploring (loop continues)
                            else:
                                print("Invalid choice. Please type 'yes' or 'no'.")

                        # After exploration ends, return to the crossroads message
                        continue

                    elif input_choice == "rest":
                        print("You take a moment to rest and recover.")
                        player.hp = min(player.hp + random.randint(10, 20), player.max_hp)
                        print(f"You now have {player.hp} HP.")

                print("Game Over. Thank you for playing!")
            else:
                print("Player is not created.")


# Start the game
if __name__ == "__main__":
    game()
